import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';

import { EditComponent } from './review/edit/edit.component';
import { DeleteComponent } from './review/delete/delete.component';
import { ReviewService } from './review/service/review.service';
import { WelcomeComponent } from './review/welcome/welcome.component';
import { ReviewlistingpageComponent } from './review/reviewlistingpage/reviewlistingpage.component';

@NgModule({
  declarations: [
    AppComponent,
    EditComponent,
    DeleteComponent,
    WelcomeComponent,
    ReviewlistingpageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [ReviewService],
  bootstrap: [AppComponent]
})
export class AppModule { }
