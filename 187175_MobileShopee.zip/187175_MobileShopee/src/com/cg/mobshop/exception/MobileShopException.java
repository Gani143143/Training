package com.cg.mobshop.exception;

public class MobileShopException extends Exception{

	public MobileShopException(String arg0) {
		super(arg0);
		
	}

}
