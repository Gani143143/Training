package com.cg.mobshop.ui;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImpl;
import com.cg.mobshop.utility.SortByMobileId;
import com.cg.mobshop.utility.SortByMobileName;
import com.cg.mobshop.utility.SortByMobilePrice;
/**
 * @author gkorada
 *
 */
public class MainUI {
    public static void main(String[] args) {
        MobileService service=new MobileServiceImpl();
        Scanner scanner = null;
        int choice = 0;
        boolean optionFlag = false;
        boolean choiceFlag = false;
        boolean deleteFlag = false;
        try {
            do {
                scanner = new Scanner(System.in);
                List<Mobiles> mobilelist = service.getAllMobiles();
                for (Mobiles mobile : mobilelist) {
                    System.out.println(mobile);
                }
                System.out.println("****** Welcome to Mobile Shopee ******");
                System.out.println("Enter your choice");
                System.out.println("1.Sorting\n2.Delete\n3.Exit");
                choice = scanner.nextInt();
                switch (choice) {
                /**
                 * this case is used to display the options available in the Sorting.
                 */
                case 1:
                    System.out.println("1.SortByMobileName\n2.SortByMobilePrice\n3.SortByMobileId");
                    int option = scanner.nextInt();
                    switch (option) {
                    /**
                     * this case is used to display the list By MobileName.
                     */
                    case 1:
                    List<Mobiles> mobilelistbyname = service.getAllMobiles();
                    Collections.sort(mobilelistbyname, new SortByMobileName());
                    System.out.println("**** Displaying the list by MobileName. ****");
                    display(mobilelistbyname);
                    break;
                    /**
                     * this case is used to display the list By MobilePrice.
                     */
                    case 2:
                        List<Mobiles> mobilelistbyprice = service.getAllMobiles();
                        Collections.sort(mobilelistbyprice, new SortByMobilePrice());
                        System.out.println("**** Displaying the list by MobilePrice. ****");
                        display(mobilelistbyprice);
                        break;
                    /**
                     * this case is used to display the list By MobileId.   
                     */
                    case 3:
                        List<Mobiles> mobilelistbypid = service.getAllMobiles();
                        Collections.sort(mobilelistbypid, new SortByMobileId());
                        System.out.println("**** Displaying the list by MobileId. ****");
                        display(mobilelistbypid);
                        break;
                    default:
                        break;
                    }
                    break;
                /**
                 * this case is used to delete the the mobile.    
                 */
                case 2: {
                    do {
                        System.out.println("Enter Mobile Id to delete");
                        int mobileId=scanner.nextInt();
                        boolean status=service.deleteMobile(mobileId);
                        if(status=true) {
                            System.out.println( mobileId+ "  Deleted Successfully......");
                            deleteFlag=true;
                        }else {
                            System.out.println("The respective mobileId is not there in the list.");
                            
                        }
                            
                    }while(!deleteFlag);
                }
                    break;
                /**
                 * this case is used to exit the loop by the user whenever required.    
                 */
                case 3:
                    System.out.println("Thank you for yor visit....");
                    System.exit(0);
                    break;
                default:
                    System.err.println("Enter 1, or 3 only");
                    break;    
                }
                /**
                 * this do while loop is used to continue the process. 
                 */
                do {
                    System.out.println("Do you want to continue yup/nope");
                    scanner = new Scanner(System.in);
                    String option = scanner.nextLine();
                    optionFlag = false;
                    if (option.equalsIgnoreCase("yup")) {
                        optionFlag = true;
                        break;
                    } else if (option.equalsIgnoreCase("nope")) {
                        optionFlag = false;
                        System.out.println("Good Bye!");
                        System.exit(0);
                    } else {
                        System.err.println("Enter only yup or nope");
                        optionFlag = false;
                        continue;
                    }


                } while (!optionFlag);
            } while (!choiceFlag);
        } catch (InputMismatchException e) {
            System.err.println("Enter valid choice");
        }


    }
    static void display(List<Mobiles>mobilelist) {
        for(Mobiles mobile : mobilelist) {
            System.out.println(mobile);
        }
}
}








