package com.cg.mobshop.test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

 

import java.util.HashMap;
import java.util.List;

 

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

 

import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;



public class MobileDAOImplTest {
    MobileDAOImpl dao=null;
    @Before
    public void setUp() throws Exception {
        dao=new MobileDAOImpl();
    }
    @After
    public void tearDown() throws Exception {
        dao=null;
    }
    @Test
    public void testGetAllMobiles() {
        List<Mobiles> mobileList=dao.getAllMobiles();
        assertEquals(4, mobileList.size());
    }
    @Test
    public void testDeleteMobile() {
        assertEquals(true, dao.deleteMobile(101));
    }
    @Test
    public void testGetAllProductsAsNegetive() {
        List<Mobiles> mobileList=dao.getAllMobiles();
        assertNotNull(mobileList);
    }
    @Test
    public void testDeleteMobileAsNegetive() {
        assertEquals(false, dao.deleteMobile(111));
    }

 

}