package com.cg.mobshop.dao;

 

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

 

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileShopException;
import com.cg.mobshop.util.Util;

 /**
  * 
  * @author gkorada
  * this is the DAOImpl class which has the methods to display and delete.
  */
public class MobileDAOImpl implements MobileDAO {
    Map<Integer, Mobiles> mobileList=Util.getMobileEntries();
    /**
     * mobileList is the map which is used to get all the mobile entries.
     */
    @Override
    /**
     * this method is used to getAllMobile details in a list.
     */
    public List<Mobiles> getAllMobiles() {
         
         Collection<Mobiles> collection = mobileList.values();
         List<Mobiles> mobilelist = new ArrayList<>();
         mobilelist.addAll(collection);
        return mobilelist;
    }
    /**
     * this method is used to delete the required mobile details.
     */

 

    @Override
    public boolean deleteMobile(int mobileId) {
           boolean idFlag=false;
            if(mobileList.containsKey(mobileId)) {
                mobileList.remove(mobileId);
                idFlag=true;
            }
            else {
                try {
                    throw new MobileShopException("Id does not exists");
                } catch (MobileShopException e) {
                    System.out.println(e.getMessage());
                }
            }
            Collection<Mobiles> collection=mobileList.values();
            List<Mobiles> mobiles=new ArrayList<>();
            mobiles.addAll(collection);
            return idFlag;
        }
    }