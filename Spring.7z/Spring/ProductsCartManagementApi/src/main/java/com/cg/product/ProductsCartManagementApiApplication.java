package com.cg.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsCartManagementApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductsCartManagementApiApplication.class, args);
	}

}
