package com.cg.product.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.product.dto.Product;



/**
 * @author gkorada
 * Date of Creation:23-08-2019
 * Interface IProduct Repository
 * Description
 *
 */
@Repository
public interface IProductRepository extends JpaRepository<Product, String>{

}
