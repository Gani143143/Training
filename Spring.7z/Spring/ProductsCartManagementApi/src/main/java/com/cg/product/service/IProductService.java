package com.cg.product.service;

import java.util.List;


import com.cg.product.dto.Product;
import com.cg.product.exception.ProductException;



/**
 * @author gkorada
 * Date of Creation:23-08-2019
 * Interface IProduct Service 
 * Description
 *
 */
public interface IProductService {
	List<Product> createProduct(Product product) throws ProductException;
	List<Product> updateProduct(String id,Product product) throws ProductException;
	List<Product> deleteProduct(String id) throws ProductException;
	List<Product> viewProducts() throws ProductException;
	Product findProductById(String id) throws ProductException;

}
