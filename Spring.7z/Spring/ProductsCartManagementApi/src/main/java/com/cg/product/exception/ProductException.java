package com.cg.product.exception;



/**
 * @author gkorada
 * Date of Creation:23-08-2019
 * Class Product Exception
 * Description
 *
 */
public class ProductException extends Exception{

	public ProductException() {
		super();
	}

	public ProductException(String message) {
		super(message);
	}

}
