package com.cg.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dao.IProductRepository;
import com.cg.product.dto.Product;
import com.cg.product.exception.ProductException;

/**
 * @author gkorada
 * Date of Creation:23-08-2019
 * Class Product Service Implementation
 * Description
 */
@Service
public class ProductServiceImpl implements IProductService {
	/**
	 * This is used for Autowiring the Dao Layer
	 */
	@Autowired
	private IProductRepository productDao;
	/**
	 * Author:gkorada
	 * Date:23-08-2019
	 * Method Name:createProduct
	 * Parameters:product
	 * return value:List of products
	 * purpose:To create products in the database/
	 */


	@Override
	public List<Product> createProduct(Product product) throws ProductException {
		try {
			productDao.save(product);
			return viewProducts();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	
	/**
	 * Author:gkorada
	 * Date:23-08-2019
	 * Method Name:updateProduct
	 * Parameters:id,product
	 * return value:List of products
	 * purpose:To update products from the database/
	 */

	@Override
	public List<Product> updateProduct(String id, Product product) throws ProductException {
		try {
			if(productDao.existsById(product.getId())) {
				Product updateProduct=product;
				updateProduct.setId(id);
				productDao.save(updateProduct);
				return viewProducts();
			}else {
				throw new ProductException("Invalid Product,Cannot be updated");
			}
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	
	/**
	 * Author:gkorada
	 * Date:23-08-2019
	 * Method Name:deleteProduct
	 * Parameters:id
	 * return value:List of products
	 * purpose:To Delete products from the database/
	 */

	@Override
	public List<Product> deleteProduct(String id) throws ProductException {
		if(productDao.existsById(id)) {
			productDao.deleteById(id);
			return viewProducts();
		}else {
			throw new ProductException("Cannot be delete.Product with Id "+id+" does not exist");
		}
	}
	
	/**
	 * Author:gkorada
	 * Date:23-08-2019
	 * Method Name:viewProducts
	 * Parameters:Nill
	 * return value:List of products
	 * purpose:To Retrieve all products from the database/
	 */

	@Override
	public List<Product> viewProducts() throws ProductException {
		try {
			return productDao.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	
	/**
	 * Author:gkorada
	 * Date:23-08-2019
	 * Method Name:findProductById
	 * Parameters:id
	 * return value:product with the specified Id
	 * purpose:To Retrieve product with the specified from the database/
	 */

	@Override
	public Product findProductById(String id) throws ProductException {
		try {
			Optional<Product> data=productDao.findById(id);
			if(data.isPresent()) {
				return data.get();
			}else {
				throw new ProductException("Product with Id "+id+" does not exist");
			}
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

}
