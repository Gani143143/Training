package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.dto.Product;
import com.cg.product.exception.ProductException;
import com.cg.product.service.IProductService;


/**
 * @author gkorada
 * Date of Creation:23-08-2019
 * Class Product Controller
 * Description
 *
 */
@RestController
@RequestMapping("/api")
public class ProductController {
	/**
	 * This is used for Autowiring the Service Layer
	 */
	@Autowired
	private IProductService productService;
	/**
	 * Author:gkorada
	 * Date:23-08-2019
	 * Method Name:createProduct
	 * Parameters:product
	 * return method:POST
	 * purpose:To create products in the database/
	 */
	//@RequestMapping(value="/products",method = RequestMethod.POST)
	@PostMapping("/products")
	public List<Product> createProduct(@RequestBody Product product) throws ProductException{
		return productService.createProduct(product);
	}
	/**
	 * Author:gkorada
	 * Date:23-08-2019
	 * Method Name:updateProduct
	 * Parameters:id,product
	 * return method:PUT
	 * purpose:To update products from the database/
	 */
	//@RequestMapping(value="/products/{id}",method=RequestMethod.PUT)
	@PutMapping("/products/{id}")
	public List<Product> updateProduct(@PathVariable String id,@RequestBody Product product) throws ProductException{
		return productService.updateProduct(id, product);
	}
	/**
	 * Author:gkorada
	 * Date:23-08-2019
	 * Method Name:deleteProduct
	 * Parameters:id
	 * return method:DELETE
	 * purpose:To Delete products from the database/
	 */
	//@RequestMapping(value="/products/{id}",method=RequestMethod.DELETE)
	@DeleteMapping("/products/{id}")
	public List<Product> deleteProduct(@PathVariable String id) throws ProductException{
		return productService.deleteProduct(id);
	}
	/**
	 * Author:gkorada
	 * Date:23-08-2019
	 * Method Name:viewProducts
	 * Parameters:Nill
	 * return method:GET
	 * purpose:To Retrieve all products from the database/
	 */
	//@RequestMapping("/products")
	@GetMapping("/products")
	public List<Product> viewProducts() throws ProductException{
		return productService.viewProducts();	
	}
	/**
	 * Author:gkorada
	 * Date:23-08-2019
	 * Method Name:findProductById
	 * Parameters:id
	 * return method:GET
	 * purpose:To Retrieve product with the specified from the database/
	 */
	@GetMapping("/products/{id}")
	public Product findProductById(@PathVariable String id) throws ProductException{
		return productService.findProductById(id);
	}
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleErrors(Exception ex){
		return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
	}

}
