package com.cg.course.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.course.dao.CourseRepository;
import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;
@Service
public class CourseServiceImpl implements CourseService {
	@Autowired
	private CourseRepository courseDao;

	@Override
	public List<Course> addCourse(Course course) throws CourseException {
		try {
			if(course.getDuration()<3) {
				throw new CourseException("Duration should not be less than 3");
			}
			if(course.getMode().equals("Online") || course.getMode().equals("Classroom")) {
				courseDao.save(course);
				return getAllCourses();
			}else {
				throw new CourseException("Mode should be either Online or Classroom");
			}
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
		
	}

	@Override
	public List<Course> getAllCourses() throws CourseException {
		try {
			return courseDao.findAll();
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public List<Course> updateCourse(String courseId, Course course) throws CourseException {
		if(courseDao.existsById(course.getCourseId())) {
			courseDao.save(course);
			return getAllCourses();
		}else {
			throw new CourseException("Invalid Course, Connot be updated");
		}
		
	}

	@Override
	public Course getCourseBycourseId(String courseId) throws CourseException {
		try {
			Optional<Course> data=courseDao.findById(courseId);
			if(data.isPresent()) {
				return data.get();
			}else {
				throw new CourseException("Course with courseId "+courseId+" does not exist");
			}
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
		
	}

	@Override
	public List<Course> deleteCourse(String courseId) throws CourseException {
		if(courseDao.existsById(courseId)) {
			courseDao.deleteById(courseId);
			return getAllCourses();
		}else {
			throw new CourseException("Cannot delete.Course with courseId "+courseId+" does not exist");
		}
		
	}

	@Override
	public List<Course> getCourseByMode(String modeName) throws CourseException {
		// TODO Auto-generated method stub
		return courseDao.getCourseByMode(modeName);
	}

}
