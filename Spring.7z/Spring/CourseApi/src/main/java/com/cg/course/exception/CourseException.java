package com.cg.course.exception;

public class CourseException extends Exception{

	public CourseException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CourseException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
