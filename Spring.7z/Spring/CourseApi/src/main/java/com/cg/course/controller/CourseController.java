package com.cg.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;
import com.cg.course.service.CourseService;

@RestController
@RequestMapping("/api")
public class CourseController {
	@Autowired
	private CourseService courseService;
	//@RequestMapping("/courses")
	@GetMapping("/courses")
	public List<Course> getAllCourses() throws CourseException{
		return courseService.getAllCourses();
	}
	//@RequestMapping(value = "/courses", method=RequestMethod.POST)
	@PostMapping("/courses")
	public List<Course> addCourse(@RequestBody Course course) throws CourseException{
		return courseService.addCourse(course);
	}
	//@RequestMapping(value = "/courses/{courseId}", method=RequestMethod.PUT)
	@PutMapping("/courses/{courseId}")
	public List<Course> updateCourse(@PathVariable String courseId,@RequestBody Course course) throws CourseException{
		return courseService.updateCourse(courseId, course);
	}
	@GetMapping("/courses/{courseId}")
	public Course getCourseBycourseId(@PathVariable String courseId) throws CourseException{ 
		return courseService.getCourseBycourseId(courseId);
	}
	//@RequestMapping(value = "/courses/{courseId}", method=RequestMethod.DELETE)
	@DeleteMapping("/courses/{courseId}")
	public List<Course> deleteCourse(@PathVariable String courseId) throws CourseException{
		return courseService.deleteCourse(courseId);
	}
	@GetMapping("/courses/mode")
	public List<Course> getCourseByMode(@RequestParam String modeName) throws CourseException{
		return courseService.getCourseByMode(modeName);
	}
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleErrors(Exception ex){
		return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
	}

}
