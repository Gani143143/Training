package com.cg.prod.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.prod.dao.ProductRepository;
import com.cg.prod.dto.Product;
import com.cg.prod.exception.ProductException;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductRepository prodDao;

	@Override
	public List<Product> addProduct(Product product) throws ProductException {
		try {
			if(product.getQuantity()<0) {
				throw new ProductException("Quantity should be greater than 0");
			}
			if(product.getCategory().equals("Mobile") || product.getCategory().equals("TV") || product.getCategory().equals("Laptop")) {
				prodDao.save(product);
				return getAllProducts();
			}else {
				throw new ProductException("Category should be either Mobile,TV or Laptop");
			}
			
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		
		try {
			return prodDao.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public List<Product> updateProduct(int id, Product product) throws ProductException {
		if(prodDao.existsById(product.getId())) {
			Product prod=prodDao.findById(id).get();
			prod.setQuantity(product.getQuantity());
			prod.setPrice(product.getPrice());
			prodDao.save(prod);
			return getAllProducts();
		}else {
			throw new ProductException("Invalid Product,Cannot be updated");
		}
		
	}

	@Override
	public List<Product> deleteProduct(int id) throws ProductException {
		if(prodDao.existsById(id)) {
			prodDao.deleteById(id);
			return getAllProducts();
		}else {
			throw new ProductException("Cannot be delete.Product with Id"+id+" does not exist");
		}
	}

	@Override
	public Product getProductById(int id) throws ProductException {
		try {
			Optional<Product> data=prodDao.findById(id);
			if(data.isPresent()) {
				return data.get();
			}else {
				throw new ProductException("Product with Id "+id+" does not exist");
			}
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public List<Product> getProductByCategory(String catName) throws ProductException {
		// TODO Auto-generated method stub
		return prodDao.getProductByCategory(catName);
	}

}
