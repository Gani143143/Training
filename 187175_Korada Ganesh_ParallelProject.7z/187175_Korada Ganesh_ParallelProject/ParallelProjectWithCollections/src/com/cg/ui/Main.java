package com.cg.ui;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.bean.AccountBean;
import com.cg.bean.TransactionBean;
import com.cg.exception.BankException;
import com.cg.service.BankServiceImpl;

public class Main {
	static Scanner scanner=new Scanner(System.in);
	static BankServiceImpl service=new BankServiceImpl();
	public static void main(String[] args) {
		boolean choiceFlag = false;
		String continueChoice;
		boolean continueValue = false;

		do {
			try {
				System.out.println("****Welocome to Bank**** \n 1.Create Account \n 2.Deposit \n 3.Withdraw \n 4.FundTransfer\n 5.ShowBalance ");
				System.out.println("Enter your choice");
				int choice = scanner.nextInt();
				switch (choice) {
				
				case 1:
					
				{
					
					String name = null;
					long mobileNumber;
					String gender;
					double balance=0;
					System.out.println("Account Creation");
					boolean flag = false;
					boolean NameFlag=false;
					boolean GenderFlag=false;
					boolean BalanceFlag=false;
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter your Name:");
						name = scanner.nextLine();
						try {
							service.validateName(name);
							NameFlag = true;
						} catch (BankException e) {
							NameFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!NameFlag);
					System.out.println("Enter your Mobile Number");
					mobileNumber = scanner.nextLong();
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter your Gender:");
						gender = scanner.nextLine();
						try {
							service.validateGender(gender);
							GenderFlag = true;
						} catch (BankException e) {
							GenderFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!GenderFlag);
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter your Balance:");
						balance = scanner.nextDouble();
						try {
							service.validateBalance(balance);
							BalanceFlag = true;
						} catch (BankException e) {
							BalanceFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!BalanceFlag);
					AccountBean account=new AccountBean(0, balance, name, mobileNumber);
					long number=service.addDetails(account);
					System.out.println("Account created  succesfully and your Account Number is "+number);
					//System.out.println(service.accountDetails(account));
				
					
				}	break;
				case 2:
				{
					long accountNo;
					int depositAmount;
					System.out.println(" ***Welcome to Deposit***");
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					System.out.println("Enter Amount");
					depositAmount=scanner.nextInt();
					long deposit=service.addDeposit(accountNo, depositAmount);
					System.out.println(deposit);
					Date transactionDate=new Date();
					TransactionBean transaction=new TransactionBean(0, transactionDate, accountNo, deposit);
					int transactionId=service.addTransaction(transaction);
					//System.out.println(service.transactionDetails(transaction));
					
				}
					break;
				case 3:
				{
					long accountNo;
					int withdrawAmount;
					System.out.println(" ***Welcome to Withdraw***");
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					System.out.println("Enter Amount");
					withdrawAmount=scanner.nextInt();
					long withdraw=service.addWithDraw(accountNo, withdrawAmount);
					if(withdraw<0) {
						System.err.println("Enter valid Amount");
					}else {
					System.out.println(withdraw);
					}
					Date transactionDate=new Date();
					TransactionBean transaction=new TransactionBean(0, transactionDate, accountNo, withdraw);
					int transactionId=service.addTransaction(transaction);
					//System.out.println(service.transactionDetails(transaction));
					
					
				}break;
				case 4:
				{
					long accountNo,accountNo2;
					int amount;
					System.out.println(" ***Welcome to FundTransfer***");
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					System.out.println("Enter Account Number to where the fund need to be transferred");
					accountNo2=scanner.nextLong();
					System.out.println("Enter Amount");
					amount=scanner.nextInt();
					long fund=service.fundDetails(accountNo, amount);
					System.out.println(fund);
					Date transactionDate=new Date();
					TransactionBean transaction=new TransactionBean(0, transactionDate, accountNo, fund);
					int transactionId=service.addTransaction(transaction);
					//System.out.println(service.transactionDetails(transaction));
					System.out.println("Fund is transfered successfully");
					
					
				}break;
				case 5:
				{
					long accountNo;
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					System.out.println("Your Account Blance is="+service.balanceCheck());
				}break;
				
				default:
					System.err.println("Choice should be 1,2,3,4 and 5");
					break;
				}

			} catch (InputMismatchException e) {
				choiceFlag = false;
				System.err.println("Input should contains digits");
			}
			do {
				scanner = new Scanner(System.in);
				System.out.println("Do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("Thank You");
					continueValue = false;
					break;
				} else {
					System.out.println("Enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		

		scanner.close();
	}

	}


