package com.cg.service;

import java.util.Map;

import com.cg.bean.AccountBean;
import com.cg.bean.TransactionBean;
import com.cg.exception.BankException;

public interface BankService {
	long addDetails(AccountBean account);
	Map<Long,AccountBean> accountDetails(AccountBean account);
	long addDeposit(long accountNo,long depositAmount);
	long addWithDraw(long accountNo,long withDrawAmount);
	double balanceCheck();
	long fundDetails(long accountNo,long fundAmount);
	int addTransaction(TransactionBean transaction);
	Map<Integer, TransactionBean> transactionDetails(TransactionBean transaction);
	boolean validateName(String name) throws BankException;
	boolean validateGender(String gender) throws BankException;
	boolean validateBalance(double balance) throws BankException;
}
