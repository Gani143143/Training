package com.capgemini.service;


import java.util.List;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.BankException;

public interface BankService {
	public long addCust(Customer customer);
	Customer getCustomer(long accountNo, String password);
	public boolean isNameValid(String name) throws BankException;
	public boolean isPhoneValid(String name) throws BankException;
	public boolean isEmailValid(String name) throws BankException;
	public boolean isAccountValid(long accountNo,String password) throws BankException;
	public boolean isAccountNoValid(long accountNo) throws BankException;
	public boolean deposit(float amount, long accountNo) throws BankException;
	public boolean withdraw(float amount, long accountNo) throws BankException;
	public boolean fundTransfer(float amount,long accountNo, long accountNo2) throws BankException;
	public List<Transaction> printTransaction(long accountNo);
}
