package com.capgemini.dao;

import java.util.List;
import java.util.Map;
import com.capgemini.bean.*;
import com.capgemini.exception.BankException;

public interface BankDAO {
	public long addCustomer(Customer customer);
	//public boolean updateCustomer(Customer customer);
	//boolean deleteCustomer(int customerId);
	Customer getCustomer(long accountNo, String password);
	Map<Integer, Customer> getCustomers();
	public boolean accountValid(long accountNo,String password);
	public boolean accountNoValid(long accountNo);
	public boolean depositAmount(float amount, long accountNo) throws BankException;
	public boolean withdrawAmount(float amount, long accountNo) throws BankException;
	public boolean fundTransferAmount(float amount,long accountNo, long accountNo2) throws BankException;
	public List<Transaction> printTransactions(long accountNo);
	
}
