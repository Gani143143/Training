package com.capgemini.service;

import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.dao.BankDaoImpl;
import com.capgemini.exception.BankException;

public class BankServiceImpl implements BankService {
	BankDaoImpl bankDao = new BankDaoImpl();

	@Override
	public long addCust(Customer customer) {
		return bankDao.addCustomer(customer);
	}

	@Override
	public Customer getCustomer(long accountNo, String password) {
		return bankDao.getCustomer(accountNo, password);
	}

	@Override
	public boolean isNameValid(String name) throws BankException {
		boolean namevalid = false;
		String regex = "^[A-Z]{1}[A-Za-z]{1,}$";
		if (!Pattern.matches(regex, name)) {
			throw new BankException("First Letter Should be Capital");
		} else {
			namevalid = true;
		}
		return namevalid;
	}

	@Override
	public boolean isPhoneValid(String mobile) throws BankException {
		boolean phonevalid = false;
		String regex = "^[7-9]{1}[0-9]{9}$";
		if (!Pattern.matches(regex, mobile)) {
			throw new BankException("Enter Valid Phone Number");
		} else {
			phonevalid = true;
		}
		return phonevalid;
	}

	@Override
	public boolean isEmailValid(String email) throws BankException {
		boolean emailValid = false;
		String regex = "^(.+)@(.+)$";
		if (!Pattern.matches(regex, email)) {
			throw new BankException("Enter Valid Email");
		} else {
			emailValid = true;
		}
		return emailValid;
	}

	@Override
	public boolean isAccountNoValid(long accountNo) throws BankException {
		boolean accountvalid = false;
		if(!bankDao.accountNoValid(accountNo))
		{
			throw new BankException("No Account Exists!!!!!");
		}
		else
		{
			accountvalid = true;
		}
		return accountvalid;
	}
	
	@Override
	public boolean isAccountValid(long accountNo,String password) throws BankException {
		boolean accountvalid = false;
		if(!bankDao.accountValid(accountNo,password))
		{
			throw new BankException("Invalid Credentials!!!!!");
		}
		else
		{
			accountvalid = true;
		}
		return accountvalid;
	}
	
	@Override
	public boolean deposit(float amount, long accountNo) throws BankException {
		boolean depositvalid = false;
		if(!bankDao.depositAmount(amount, accountNo))
		{
			throw new BankException("Transaction failed : Amount cannot be less than zero");
		}
		else
		{
			depositvalid = true;
		}
		return depositvalid;
	}

	@Override
	public boolean withdraw(float amount, long accountNo) throws BankException {
		boolean withdrawvalid = false;
		if(!bankDao.withdrawAmount(amount, accountNo))
		{
			throw new BankException("Transaction failed : Insufficient Balance");
		}
		else
		{
			withdrawvalid = true;
		}
		return withdrawvalid;
	}

	@Override
	public boolean fundTransfer(float amount, long accountNo, long accountNo2) throws BankException {
		boolean transfervalid = false;
		if(!bankDao.fundTransferAmount(amount, accountNo, accountNo2))
		{
			throw new BankException("Transaction failed");
		}
		else
		{
			transfervalid = true;
		}
		return transfervalid;
	}

	@Override
	public List<Transaction> printTransaction(long accountNo) {
		return bankDao.printTransactions(accountNo);
	}


}
