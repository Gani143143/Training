package com.capgemini.bean;



public class Customer {
	private String name;
	private String email;
	private String mobile;
	private String password;
	private long accountNo;
	private float balance;
	public Customer() {
		super();
	}
	
	public Customer(String name, String email, String mobile, long accountNo, float balance, String password) {
		super();
		this.password = password;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.accountNo = accountNo;
		this.balance = balance;
	}
	public Customer(String name, String email, String mobile, String password) {
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.password = password;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPassword() {
		return password;
	}
	public void setAddress(String password) {
		this.password = password;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "\nCustomer Information "+ "\nName : " + name + "\nEmail : " + email + "\nMobile : " + mobile
				+ "\nPassword : " + password + "\nAccountNo : " + accountNo + "\nBalance : " + balance ;
	}
	
}
