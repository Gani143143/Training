package com.capgemini.bean;

public class Transaction {
	private long transactionId;
	private String transactionType;
	private String transactionDate;
	private int customerId;
	private long accountNo;
	private double amount;
	public Transaction() {
		super();
	}
	
	public Transaction(long transactionId, String transactionType, String transactionDate, long accountNo,
			double amount) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.accountNo = accountNo;
		this.amount = amount;
	}

	public Transaction(long transactionId, String transactionType, String transactionDate, int customerId, long accountNo,
			double amount) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.customerId = customerId;
		this.accountNo = accountNo;
		this.amount = amount;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return  "[TransactionId : " + transactionId + "| TransactionType : " + 
				transactionType	+ "| Transaction Date : " + transactionDate + "  | Amount=" + amount + "]";
	}
}
