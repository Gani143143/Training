package com.capgemini.Exceptionlayer;

public class AccountException extends Exception {
	public AccountException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}



}
