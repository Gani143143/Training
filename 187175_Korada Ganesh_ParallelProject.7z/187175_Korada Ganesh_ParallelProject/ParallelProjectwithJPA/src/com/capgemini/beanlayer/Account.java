package com.capgemini.beanlayer;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="account1")
public class Account {
	@Id
	
	private String name;
	private double balance;
	private long accountNo;
	private int password;
	@OneToMany
	private List<Transaction> list1;
	public List<Transaction> getList1() {
		return list1;
	}

	public void setList1(List<Transaction> list1) {
		this.list1 = list1;
	}

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Account(String name, double balance, long accountNo, int password) {
		super();
		this.name = name;
		this.balance = balance;
		this.accountNo = accountNo;
		this.password = password;
	}

	public Account(String name, double balance, long accountNo) {
		super();
		this.name = name;
		this.balance = balance;
		this.accountNo = accountNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	
	public int getPassword() {
		return password;
	}

	public void setPassword(int password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Account [name=" + name + ", balance=" + balance + ", accountNo=" + accountNo + ", password=" + password
				+ "]";
	}

}
