package com.capgemini.daolayer;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capgemini.Exceptionlayer.AccountException;
import com.capgemini.beanlayer.Account;
import com.capgemini.beanlayer.Customer;
import com.capgemini.beanlayer.Transaction;

public class DaoImpl implements DaoInterface{
	static Account account= new Account();
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA");
	EntityManager em=factory.createEntityManager();
	
	public int getCustomerId() throws AccountException {
		double generatedId = Math.random() * 10000;
		int Id = (int) generatedId;
		return Id;
	}

	public long generateAccountNo() throws AccountException {
		double generatedId = Math.random() * 10000000;
		long Id = (long) generatedId;
		return Id;
	}

	@Override
	public boolean addAccount(Account account) throws AccountException {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
	em.persist(account);
	em.getTransaction().commit();
		return true;
	}

	@Override
	public Account ValidateLogin(String name, int pass) throws AccountException {
		// TODO Auto-generated method stub
		boolean status=false;
	Account account1=	em.find(Account.class, name);
	if(account1.getPassword()==pass) {
		status=true;
	}
	if(!status)
	{
		throw new AccountException("there is no user with the given details");
	}
		return account1;
	}

	@Override
	public double getBalance(String name, int pass) throws AccountException {
		// TODO Auto-generated method stub
		double balance=0;
		Account account1=	em.find(Account.class, name);
		if(account1.getPassword()==pass) {
			balance=account1.getBalance();
		}
		return balance;
	}

	@Override
	public boolean withdraw(double amt, String name, int pass) throws AccountException {
		// TODO Auto-generated method stub
		double balance=0;
		em.getTransaction().begin();
		Account account1=	em.find(Account.class, name);
		if(account1.getPassword()==pass) {
			balance=account1.getBalance();
			balance=balance-amt;
			account1.setBalance(balance);
		}
		em.getTransaction().commit();
		
		return true;
	}

	@Override
	public boolean deposit(double amt, String name, int pass) throws AccountException {
		// TODO Auto-generated method stub
		double balance=0;
		em.getTransaction().begin();
		Account account1=	em.find(Account.class, name);
		if(account1.getPassword()==pass) {
			balance=account1.getBalance();
			balance=balance+amt;
			account1.setBalance(balance);
		}
		em.getTransaction().commit();
		
		return true;
	}

	@Override
	public boolean addCustomer(Customer customer) throws AccountException {
		em.getTransaction().begin();
		em.persist(customer);
		em.getTransaction().commit();
			return true;
	}

	@Override
	public int generateId() throws AccountException {
		double generatedId = Math.random() * 1000;
		int Id = (int) generatedId;
		return Id;
	}

	@Override
	public boolean addtransaction(Transaction transaction) throws AccountException {
		em.getTransaction().begin();
		em.persist(transaction);
		em.getTransaction().commit();
			return true;
}

	@Override
	public List<Transaction> getTrans(String name, int pass) throws AccountException {
		// TODO Auto-generated method stub
		TypedQuery<Transaction> query=em.createQuery("from Transaction where custId=?", Transaction.class);
		query.setParameter(1, pass);
		System.out.println("executing");
		List<Transaction> list11=query.getResultList();
		return list11;
	}


}
