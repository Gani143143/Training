import { Component, OnInit } from '@angular/core';
import { Customer, Transactions, CustomerService } from '../customer.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  isLogin:boolean=true;
  customers:Customer[]=[];
  upBal:number;
  isDeposit:boolean=true;
  service:CustomerService;
  constructor(service:CustomerService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  depositeAmount(data:any){
    let caccount_first=this.service.loginAccount;
    var deposit = this.service.depositeBalance(caccount_first,data.cbalance);
    deposit.subscribe((data)=> {
      this.upBal=data;
    })
    this.isDeposit=!this.isDeposit;
  }

  ngOnInit() {
    this.customers=this.service.getCustomers();
  }
}
