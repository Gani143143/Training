package com.capgemini.review.service;


import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.review.bean.Review;
import com.capgemini.review.dao.ReviewRepository;
import com.capgemini.review.exception.ReviewException;




@Service
public class ReviewServiceImpl implements ReviewService {

	
	@Autowired
	private ReviewRepository reviewDao;
	@Override
	public List<Review> getAllReviews() throws ReviewException {
		return reviewDao.findAll();
	}

	@Override
	public List<Review> addReview(Review review) throws ReviewException {
		long millis=System.currentTimeMillis();
        java.sql.Date date=new java.sql.Date(millis);
		/*
		 * try { millis = formatter.parse(dt); } catch (ParseException e) {
		 * System.out.println(e.getMessage()); }
		 */
        review.setReviewOn(date);
        System.out.println(review);
        reviewDao.save(review);
		return getAllReviews();
	}

	@Override
	public List<Review> deleteReview(int Id) throws ReviewException {
		reviewDao.deleteById(Id);
		return getAllReviews();
	}

	@Override
	public List<Review> editReview(int Id, Review review) throws ReviewException {
		if(reviewDao.existsById(review.getId())) {
			Review rev=reviewDao.findById(Id).get();
			rev.setHeadline(review.getHeadline());
			rev.setReviewOn(review.getReviewOn());
			reviewDao.save(rev);
			return getAllReviews();
		}else {
			throw new ReviewException("Invalid Book,Cannot be updated");
		}
	}
	@Override
    public Review getReviewById(int Id) throws ReviewException {
        
            try {
            Optional<Review> data=reviewDao.findById(Id);
            if(data.isPresent()) {
                return data.get();
            }
            else {
                throw new ReviewException("Review with id "+Id+" does not exist");
            }
        } catch (Exception e ) {
            throw new ReviewException(e.getMessage());
       
       
            }
	}



}
