package com.capgemini.review.controller;

 

import java.util.List;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

 

import com.capgemini.review.bean.Review;
import com.capgemini.review.exception.ReviewException;
import com.capgemini.review.service.ReviewService;

 

@RestController
@RequestMapping
@CrossOrigin(origins="http://localhost:4200")
public class ReviewController {

 

    @Autowired
    private ReviewService reviewService;
    
    
    @GetMapping("/reviews")
    public List<Review> getAllReviews() throws ReviewException{
        System.out.println(reviewService.getAllReviews());
        return reviewService.getAllReviews();
    }
    
    @PostMapping("/reviews")
    public List<Review> addReview(@RequestBody Review review) throws ReviewException{
    	System.out.println(review);
        return reviewService.addReview(review);
    }
    
    @DeleteMapping("/reviews/{Id}")
    public List<Review> deleteReview(@PathVariable int Id) throws ReviewException{
            return reviewService.deleteReview(Id);
    
    }
    
    @PutMapping("/reviews/{Id}")
    public List<Review> editReview(@RequestBody Review review,@PathVariable int Id) throws ReviewException{
        return reviewService.editReview(Id,review);
    }
    
    @GetMapping("/reviews/{Id}")
    public Review getReviewById(@PathVariable int Id) throws ReviewException {
        return reviewService.getReviewById(Id);
    }
    @ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleErrors(Exception ex){
		return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
	}
    
    
}