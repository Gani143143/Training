package com.capgemini.review.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="review")
public class Review {

	private int index;
	@Id
	@SequenceGenerator(name = "ID_Generator", sequenceName = "reviewseq",initialValue = 5, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID_Generator")
	private int Id;
	private String Book;
	private int Rating;
	private String Headline;
	private String Customer;
	private String ReviewOn;
	public Review(int index, int id, String book, int rating, String headline, String customer, String reviewOn) {
		super();
		this.index = index;
		Id = id;
		Book = book;
		Rating = rating;
		Headline = headline;
		Customer = customer;
		ReviewOn = reviewOn;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getBook() {
		return Book;
	}
	public void setBook(String book) {
		Book = book;
	}
	public int getRating() {
		return Rating;
	}
	public void setRating(int rating) {
		Rating = rating;
	}
	public String getHeadline() {
		return Headline;
	}
	public void setHeadline(String headline) {
		Headline = headline;
	}
	public String getCustomer() {
		return Customer;
	}
	public void setCustomer(String customer) {
		Customer = customer;
	}
	public String getReviewOn() {
		return ReviewOn;
	}
	public void setReviewOn(String reviewOn) {
		ReviewOn = reviewOn;
	}
	
	
}
