package com.capgemini.review.service;

import java.util.List;

import com.capgemini.review.bean.Review;
import com.capgemini.review.exception.ReviewException;


public interface ReviewService {

	List<Review> getAllReviews() throws ReviewException;
	List<Review> addReview(Review review) throws ReviewException;
	List<Review> deleteReview(int Id) throws ReviewException;
	List<Review> editReview(int Id,Review review)throws ReviewException;
	Review getReviewById(int id) throws ReviewException;
}
