package com.capgemini.presentation;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import com.capgemini.bean.Customer;
import com.capgemini.service.CustomerService;
import com.capgemini.service.CustomerServiceImpl;

public class MainUI {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		CustomerService service=new CustomerServiceImpl();
		boolean status=false;
		while(true) {
			System.out.println("1.Register\n2.Update\n3.Delete\n4.ViewById\n5.ViewAll");
			int choice=scanner.nextInt();
			switch (choice) {
			case 0:System.exit(0);
			case 1:{
				try {
				System.out.println("Enter name,address,phone");
				String name=scanner.next();
				String address=scanner.next();
				long phone=scanner.nextLong();
				System.out.println("Enter DOB format should be dd-MM-yy");
				String dob=scanner.next();
				SimpleDateFormat sf=new SimpleDateFormat("dd-MM-yy");
				Date d=sf.parse(dob);
				Customer customer=new Customer(0,name,address,d,phone);
				int custId=service.saveCustomer(customer);
				if(custId>0) 
					System.out.println("Customer Registered successfully and your id is:"+custId);
				else
					System.out.println("Not Registered try again...");
				}catch(ParseException e) {
					e.printStackTrace();
				}
			}break;
			case 2:{
				try {
				System.out.println("Enter custid to update");
				int custid=scanner.nextInt();
				System.out.println("Enter name,address,phone");
				String name=scanner.next();
				String address=scanner.next();
				long phone=scanner.nextLong();
				System.out.println("Enter DOB format should be dd-MM-yy");
				String dob=scanner.next();
				SimpleDateFormat sf=new SimpleDateFormat("dd-MM-yy");
				Date d=sf.parse(dob);
				Customer customer=new Customer(0,name,address,d,phone);
				status=service.updateCustomer(customer);
				if(status) 
					System.out.println("Customer Updated successfully");
				else
					System.out.println("Not updated try again...");
				}catch(ParseException e) {
					e.printStackTrace();
				}
			}break;
			case 3:{
				System.out.println("Enter custid to delete");
				int custid=scanner.nextInt();
				
				status=service.removeCustomer(custid);
				if(status) 
					System.out.println("Customer deleted successfully ");
				else
					System.out.println("Not deleted try again...");
			}break;
			case 4:{
				System.out.println("Enter custid to view");
				int custid=scanner.nextInt();
				
				Customer customer=service.viewById(custid);
				if(customer!=null) 
					System.out.println(customer);
				else
					System.out.println("Customer not found try again...");
			}break;
			case 5:{
					List<Customer> customerlist = service.viewAll();
					
					if(customerlist!=null) 
						System.out.println(customerlist);
					else
						System.out.println("Customerlist not found try again...");
			}break;

			default:
				System.out.println("input should be 1,2,3,4 or 5");
				break;
		    }
		}

}

}
