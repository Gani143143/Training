package com.capgemini;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

import com.capgemini.utility.DBConnection;

public class CallableDemo {
	public static void main(String[] Args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter empno to view");
		int empno=scanner.nextInt();
		try(Connection connection=DBConnection.getConnection();){
			CallableStatement statement=connection.prepareCall(
					"{call empdata(?,?,?)}");
			statement.setInt(1, empno);
			statement.registerOutParameter(2, Types.VARCHAR);
			statement.registerOutParameter(3, Types.NUMERIC);
			statement.execute();
			String name=statement.getString(2);
			int salary=statement.getInt(3);
			System.out.println("Name:"+name+"\nSalary:"+salary);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}
