package com.cg.client;

import com.cg.MyThread;

public class MyThreadClient {

	public static void main(String[] args) {
		MyThread thread1=new MyThread("one");
		thread1.setName("First");
		MyThread thread2=new MyThread("two");
		thread2.setName("Second");
		MyThread thread3=new MyThread("three");
		thread3.setName("Third");
		//thread3.setPriority(Thread.MAX_PRIORITY);
		//thread1.setPriority(Thread.MIN_PRIORITY);
		thread1.start();
		try {
			thread1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		thread2.start();
		thread3.start();

	}

}
