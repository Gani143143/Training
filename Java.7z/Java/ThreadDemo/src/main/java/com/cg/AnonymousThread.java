package com.cg;

public class AnonymousThread {

}
