package com.cg.client;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.cg.MyTask;
import com.cg.MyThread;

public class ExecutorMain {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		MyTask task=new MyTask();
		Thread t=new MyThread();
		t.start();
		//ExecutorService es=Executors.newSingleThreadExecutor();
		//ExecutorService es=Executors.newFixedThreadPool();
		ExecutorService es=Executors.newCachedThreadPool();
		es.execute(new MyTask());
		es.execute(new MyTask());
		es.execute(new MyTask());
		es.execute(new MyTask());
		Future f=es.submit(new MyTask());
		System.out.println("Result:"+f.get());
		System.out.println("Is finished:"+f.isDone());

	}

}
