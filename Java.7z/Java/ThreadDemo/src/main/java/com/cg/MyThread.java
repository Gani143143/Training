package com.cg;

public class MyThread extends Thread {
	String name;
	public MyThread() {
		
	}
	public MyThread(String name) {
		super();
		this.name=name;
	}
	@Override
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println(Thread.currentThread().getName()+" is "+name+"==> "+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
	}

}
