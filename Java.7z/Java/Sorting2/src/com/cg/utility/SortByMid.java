package com.cg.utility;

import java.util.Comparator;

import com.cg.bean.Mobile;



public class SortByMid implements Comparator<Mobile>{

	@Override
	public int compare(Mobile p1, Mobile p2) {
		if(p1.getMid()>p2.getMid())
		return 1;
	else if(p1.getMid()<p2.getMid())
		return -1;
	else
	    return 0;
	}

}

