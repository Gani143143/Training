package com.cg.repository;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Mobile;


public class MobileRepository {
	public static HashMap<Integer, Mobile> map=new HashMap<>();
	public static HashMap<Integer, Mobile> getAllMobiles(){
		map.put(44, new Mobile(44,"Mi",98989));
		map.put(33, new Mobile(33,"Nokia",44545));
		map.put(22, new Mobile(22,"Apple",50000));
		map.put(55, new Mobile(55,"Poco",58500));
		map.put(77, new Mobile(77,"Samsung",20000));
		return map;
		
	}

}
