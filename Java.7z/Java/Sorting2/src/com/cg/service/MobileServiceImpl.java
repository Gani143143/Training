package com.cg.service;

import java.util.HashMap;
import java.util.List;

import com.cg.bean.Mobile;
import com.cg.dao.MobileDao;
import com.cg.dao.MobileDaoImpl;

public class MobileServiceImpl implements IMobileService {
	MobileDao dao=new MobileDaoImpl();

	@Override
	public List<Mobile> getAllMobiles() {
		// TODO Auto-generated method stub
		return dao.getAllMobiles();
	}

	@Override
	public int addMobile(Mobile mobile) {
		// TODO Auto-generated method stub
		return dao.addMobile(mobile);
	}

	@Override
	public boolean deleteMobile(int mobileId) {
		boolean status=dao.deleteMobile(mobileId);
		if(status=true) {
			
			status=true;
		}
		
		
		return status;
	}

}
