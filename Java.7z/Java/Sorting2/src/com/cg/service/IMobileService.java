package com.cg.service;

import java.util.HashMap;
import java.util.List;

import com.cg.bean.Mobile;

public interface IMobileService {

	List<Mobile> getAllMobiles();

	int addMobile(Mobile mobile);

	boolean deleteMobile(int mobileId);

}
