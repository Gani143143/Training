package com.cg.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.bean.Mobile;

public interface MobileDao {

	List<Mobile> getAllMobiles();

	int addMobile(Mobile mobile);

	boolean deleteMobile(int mobileId);

}
