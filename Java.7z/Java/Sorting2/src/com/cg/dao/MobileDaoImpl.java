package com.cg.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.cg.bean.Mobile;
import com.cg.repository.MobileRepository;

public class MobileDaoImpl implements MobileDao {
	boolean status=false;

	static Map<Integer, Mobile> map = MobileRepository.getAllMobiles();

	@Override
	public List<Mobile> getAllMobiles() {
        Collection<Mobile> collection=map.values();
		
		List<Mobile> mobilelist=new ArrayList<>();
		
		mobilelist.addAll(collection);
		
		Collections.sort(mobilelist);
		
		return mobilelist;
	}

	@Override
	public int addMobile(Mobile mobile) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean deleteMobile(int mobileId) {
		// TODO Auto-generated method stub
		return false;
	}

}
