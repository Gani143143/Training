package com.cg.lab3;
import java.util.Scanner;
public class Exercise1 {
    int temp;
        public int secondElement(int a[],int n) {
            for (int i = 0; i < n; i++) {
                for (int j = i+1; j < n; j++) {
                    if(a[i]>a[j]) {
                        temp=a[i];
                        a[i]=a[j];
                        a[j]=temp;   
                    }
                }
            }
            return a[1];
        }
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter size");
        int n=scanner.nextInt();
        System.out.println("Enter elements");
        int a[]=new int[n];
        int count;
        for (int i = 0; i < a.length; i++) {
            a[i]=scanner.nextInt();
        }
        Exercise1 secondSmallestElement=new Exercise1();
        int res=secondSmallestElement.secondElement(a, n);
        System.out.println("second element is:"+res);
    }

 

}