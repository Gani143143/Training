package com.cg.lab3;
import java.util.Scanner;
public class Exercise2 {
    public static String[] sortedArray(String array[]) {
        String newArray[] = new String[array.length];
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = i + 1; j < array.length; j++) {
                if ((array[i].compareToIgnoreCase(array[j])) > 0) {
                    String temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
        }
        if ((array.length) % 2 == 0) {


            int i = 0;
            while (i != array.length / 2) {
                newArray[i] = array[i].toUpperCase();
                i = i + 1;
            }
            while (i != array.length) {
                newArray[i] = array[i].toLowerCase();
                i = i + 1;
            }
            return newArray;
        } else {
            int i = 0;
            while (i != ((array.length / 2) + 1)) {
                newArray[i] = array[i].toUpperCase();
                i = i + 1;
            }
            while (i != array.length) {
                newArray[i] = array[i].toLowerCase();
                i = i + 1;
            }
            return newArray;
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Size :");
        int size = scanner.nextInt();


        String array[] = new String[size];
        System.out.println("Enter the Elements :");
        scanner.nextLine();
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextLine();
        }
        scanner.close();
        String output[] = sortedArray(array);


        System.out.println("New array: ");
        for (int i = 0; i < output.length; i++) {
            System.out.println(output[i]);
        }
    }
}
 










