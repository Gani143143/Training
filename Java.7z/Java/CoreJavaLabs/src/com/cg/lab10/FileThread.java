package com.cg.lab10;

 

public class FileThread extends CopyDataThread{
    public FileThread(String inputpath) {
        super();
        
    }

 

public static void main(String[] args) {
    FileThread fileProgram = new FileThread("C:\\CoreJavaSpace\\CoreJava\\src\\com\\cg\\java\\lab10\\source.txt");
    fileProgram.run();
}
}