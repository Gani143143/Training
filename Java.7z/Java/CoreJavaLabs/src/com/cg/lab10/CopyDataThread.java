package com.cg.lab10;

 

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

 

public class CopyDataThread extends Thread {
    
    public void readwrite(String inputpath) {
        FileInputStream fileInputStream = null;
        FileOutputStream fileOutputStream = null;

 

        try {

 

            fileInputStream = new FileInputStream(inputpath);
            fileOutputStream = new FileOutputStream("target.txt");

 

            int i = 0;
            while (i != -1) {
                i = fileInputStream.read();
                fileOutputStream.write(i);

 

                if (i % 10 == 0) {
                    System.out.println("10 characters are copied");
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

 

            }

 

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        readwrite("C:\\CoreJavaSpace\\corejavaProject\\src\\com\\cg\\lab10\\DisplayTimer.java");
    }
    public static void main(String[] args) {
        CopyDataThread t1=new CopyDataThread();
        t1.start();
    }
}