package com.cg.lab1;
public class Exercise3 {
    public static boolean checkNumber(int n) {
        boolean number = true;
        int num = n%10;
        n = n/10;
        int num1 = n%10;
        while(n>0)
        {
            if(num1>num)
            {
                return false;
            }
            num = num1;
            n = n/10;
            num1 = n%10;
        }
        return number;
    }
    public static void main(String[] args) {
        System.out.println("SUM : " + checkNumber(124498));
    }
}