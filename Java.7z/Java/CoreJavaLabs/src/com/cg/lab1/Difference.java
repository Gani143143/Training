package com.cg.lab1;
import java.util.Scanner;
public class Difference {
	int n,s1,s2,d;
	public int calculateDifference(int n){
		s1 = (n*(n+1)/2)*(n*(n+1)/2);
		s2 = (n*(n+1)*(2*n+1)/6);
		d = s2-s1;
		return d;		
	} 
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter n");
		int n=scanner.nextInt();
		Difference difference = new Difference();
		int d=difference.calculateDifference(n);
		System.out.println(d);
	}
}
