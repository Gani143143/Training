package com.cg.lab1;

import java.util.Scanner;

public class Sum {
	static int calculateSum(int N)  
	{  
	    int S1, S2, S3;
	    S1 = ((N / 3)) * (2 * 3 + (N / 3 - 1) * 3) / 2;  
	    S2 = ((N / 5)) * (2 * 5 + (N / 5 - 1) * 5) / 2;  
	    S3 = ((N / 15)) * (2 * 15 + (N / 15 - 1) * 15) / 2;  
	    return S1 + S2 - S3;  
	}  
	public static void main(String[] args) {
		System.out.println("enter N");
		Scanner scanner = new Scanner(System.in);
		
		int N=scanner.nextInt();
		Sum num=new Sum();
		int s=num.calculateSum(N);
	    System.out.print("sum is:"+s);

	}

}
