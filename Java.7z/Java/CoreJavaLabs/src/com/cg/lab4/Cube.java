package com.cg.lab4;
import java.util.Scanner;
public class Cube {
    public int cubing(int number) {
        int remainder,result=0;
        while(number!=0) {
            remainder=number%10;
            result=result + remainder*remainder*remainder;
            number=number/10;
                
        }
        return result;
        
    }
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter value");
        Cube cube=new Cube();
        int number=scanner.nextInt();
        int result=cube.cubing(number);
        System.out.println("Cubing of number is :" + result);
    }
}    