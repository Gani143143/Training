package com.cg.lab5;
import java.util.Scanner;
class UserDefinedException extends Exception{
	UserDefinedException(){
		System.out.println("Name is invalid try again");

	}	
	public UserDefinedException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);		
	}
	public UserDefinedException(String arg0, Throwable arg1) {
		super(arg0, arg1);	
	}
	public UserDefinedException(String arg0) {
		super(arg0);	
	}
	public UserDefinedException(Throwable arg0) {
		super(arg0);
	}	
}
public class EmployeeName {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter First Name");
		String s1=sc.nextLine();
		System.out.println("Enter Last Name");
		String s2=sc.nextLine();
		try {			
			if(s1.trim().isEmpty()||s1==null || s2==null||s2.trim().isEmpty()) {
				throw new UserDefinedException("Name is invalid try again");
			}	
			else {
				System.out.println(s1);
				System.out.println(s2);
			}	
					
		}
		catch (UserDefinedException e) {
			System.out.println(e.getMessage());
		}
		
	}
}
