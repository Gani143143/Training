package com.cg.lab5;

import java.util.Scanner;

public class Prime {
	public void number(int n) {
		int count=0;
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=n;j++) {
				if(i%j==0)
					count=count+1;			
			}
			if(count==2) {
				System.out.println(i);
			}
			count=0;
		}		
	}	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter number");
		int n=scanner.nextInt();
		Prime obj=new Prime();
		obj.number(n);		
	}
}
