package com.cg.lab5;

import java.util.Scanner;

public class TrafficLights {
	int Red=1,Yellow=2,Green=3;
	static int s;
	public  void method(int s){
		switch(s) {
		case 1:
			System.out.println("STOP");
			break;
		case 2:
			System.out.println("READY");
			break;
		case 3:
			System.out.println("GO");
			break;	    	
		}	
	}
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter your value");
		int s=scanner.nextInt();
		TrafficLights obj=new TrafficLights();
		obj.method(s);
		scanner.close();
	}
}
