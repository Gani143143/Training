package com.cg.lab5;
import java.util.Scanner;
class AgeException extends Exception{
	AgeException(){
		System.out.println("Age should be greater than fifteen");
	}
}
public class Age {	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter age");
		int age=scanner.nextInt();
		try {			
			if(age<15)
				throw new AgeException();
			else
				System.out.println("proper age " +age);			
		}catch(AgeException e) {
			
		}
	}

}
