package com.cg.lab5;

import java.util.Scanner;

public class FibonacciSequence {
	int n;
	public int fibonacci(int n) {
		if(n<2)
			return 1;
		else
			return fibonacci(n-1)+fibonacci(n-2);
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter value");
		int n=sc.nextInt();
		FibonacciSequence obj=new FibonacciSequence();
		System.out.println(obj.fibonacci(n));

	}

}
