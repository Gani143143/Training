package com.cg.lab5;
import java.util.Scanner;
class validSalary extends Exception{
    
    private static final long serialVersionUID = 1L;
    public validSalary(String s) {
        super(s);
    }
}
public class Exercise6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Salary : ");
        int salary = scanner.nextInt();
        scanner.close();
        try {
            if (salary < 30000) {
                throw new validSalary("The salary is below 30000");
            } 
        } catch (validSalary e) {
            System.out.println(e.getMessage());
        }    
    }
}
