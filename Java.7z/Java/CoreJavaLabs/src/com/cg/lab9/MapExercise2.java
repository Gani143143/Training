package com.cg.lab9;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapExercise2 {
	public static Map<Character, Integer> countCharacter(char[] array) {
		Map<Character, Integer> map = new HashMap<>();
		for (int i = 0; i < array.length; i++) {
			if (map.containsKey(array[i])) {
				map.put(array[i], map.get(array[i]) + 1);
			} else {
				map.put(array[i], 1);
			}
		}
		return map;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter string: ");
		String n = scanner.next();
		char array[] = n.toCharArray();
		System.out.println(countCharacter(array));
		scanner.close();
	}
}