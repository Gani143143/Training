package com.cg.lab8;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Exercise2 {
	public static void main(String[] args) {
		FileInputStream fileInputStream = null;
		FileOutputStream fileOutputStream = null;
		try {
			fileInputStream = new FileInputStream("src/com/cg/lab8/Exercise1.java");
			fileOutputStream = new FileOutputStream("my.doc");
			int i = 0;
			int line = 0;
			while (i != -1) {
				i = fileInputStream.read();
				fileOutputStream.write(i);
				if ((char) i == '\n') {
					line++;
					System.out.print(line + " ");
				} else {
					System.out.print((char) i);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
