package com.cg.lab8;
import java.util.Scanner;
public class Exercise5 { 
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter The String : ");
        String s = scanner.nextLine();
        scanner.close();
        char[] c = s.toCharArray();
        int check = 1;
        for(int i=c.length-1;i>1;i--) {
            if(c[i]<c[i-1]) {
                check=0;
            }
        }
        if(check==1) {
            System.out.println("true");
        }
        else {
            System.out.println("false");
        }        
    }
}