package com.cg.lab8;

import java.io.*;
public class Exercise3 {
        public static void main(String args[]) throws IOException {
            File file = new File("C:\\Users\\vymuthum\\Desktop\\game.txt");
            BufferedReader b = new BufferedReader(new FileReader(file)); 
          
            String str;
            int linecount=0,charcount=0;
            String[] word = null;
            int wordcount=0;
            
            while ((str = b.readLine()) != null) {
                //System.out.println(str);
                linecount++;
                if(!(str.equals(""))){
                    charcount = charcount + str.length();
                    word = str.split(" ");
                    wordcount = wordcount+ word.length;
                    
                }
                b.close();
            }
            System.out.println(charcount + " " + linecount  + " " + wordcount); 
            
          } 
    }
