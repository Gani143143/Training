package com.cg.lab8;
import java.io.File;
import java.util.Scanner;
public class Exercise4 { 
    public static void main(String[] args) {   
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter The Path : ");
        String s = scanner.nextLine();
        scanner.close();
        File file = new File(s);
        System.out.println(file.exists() ?"File exists": "File Does Not exists");
        System.out.println(file.canRead() ?"File ReadAble": "File Not Readable");
        System.out.println(file.canWrite() ?"File WriteAble": "File Not Writeable");
        int n = s.lastIndexOf(".");
        System.out.println("Type : " + s.substring(n+1, s.length()));
        System.out.println("Size : " + file.length());
    }
}