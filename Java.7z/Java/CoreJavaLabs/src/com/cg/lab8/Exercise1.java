package com.cg.lab8;
import java.util.StringTokenizer;
public class Exercise1 {
    public static void main(String[] args) {
        String s = "1 2 3 3 4 4 5 5 6 6 5";
        StringTokenizer st = new StringTokenizer(s," ");
        int sum=0;
        try {
            while(st.hasMoreTokens()) {
                String t = st.nextToken();
                int n= Integer.parseInt(t);
                System.out.print(n+" : ");
                sum = sum+ n;
            }
            System.out.println("Sum : "+sum);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }     
    }
}