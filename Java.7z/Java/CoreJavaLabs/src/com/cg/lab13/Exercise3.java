package com.cg.lab13;
import java.util.function.Predicate;
public class Exercise3 {
    public static void main(String[] args) {
        Predicate<String> getUserName = (name) -> name == "Ganesh Korada";
        Predicate<String> getPassword = (password) -> password == "9997777777";
        boolean result = getUserName.test("Ganesh. Korada");
        System.out.println(result);
        boolean result2 = getPassword.test("9997777777");
        System.out.println(result2);
    }
}
