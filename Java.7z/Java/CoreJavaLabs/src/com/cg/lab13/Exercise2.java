package com.cg.lab13;

@FunctionalInterface
interface StringSpace {
	String getString(String name);
}

public class Exercise2 {
	public static void main(String[] args) {
		StringSpace stringspace = (v) -> v.replace("", " ").trim();
		String name = stringspace.getString("Gani");
		System.out.println(name);
	}
}