package com.capgemini.dao;

import java.util.HashMap;
import java.util.List;

import com.capgemini.bean.Product;

public interface ProductDao {

	List<Product> getAllProducts();

	HashMap<Integer,Product> addProducts(Product product);

	HashMap<Integer,Product> deleteProduct(int productId);
}
