package com.cg.ui;

import java.util.List;

import java.util.Scanner;
import com.cg.bean.AccountDetails;
import com.cg.bean.TransactionDetails;
import com.cg.service.ServiceAccount;

public class Main {
	static Scanner scanner = new Scanner(System.in);
	static ServiceAccount service = new ServiceAccount();

	public static void main(String[] args) {

	
		for (;;) {
			System.out.println();
			System.out.print(
					"1. Create Account\n2. Show Balance\n3. Deposit\n4. Withdraw\n5. Fund Transfer\n6. Print Transactions\n7. Exit\nEnter Your Choice: ");
			switch (scanner.nextInt()) {
			case 1: {
				AccountDetails account = new AccountDetails();
				System.out.print("Enter your Name: ");
				account.setName(scanner.next());
				account.setAccountNumber((int) (Math.random() * 1000));
				System.out.println("Your Account Number is: " + account.getAccountNumber());
				System.out.print("Enter your first Deposit: ");
				account.setAmount(scanner.nextDouble());
				service.createAccount(account);

			}
				break;
			case 2: {
				System.out.print("Enter Your Account Number: ");
				System.out.println("Your Account Balance is: " + service.showBalance(validateAccountNumber()));
			}
				break;
			case 3: {
				System.out.print("Enter Your Account Number: ");
				int accountNumber = validateAccountNumber();
				System.out.print("Enter the amount you want to deposit: ");
				double credit = scanner.nextInt();
				System.out.println("Balance credited to account: " + accountNumber + "\nCredited: " + credit
						+ "\nAvailable balance is: " + service.deposit(accountNumber, credit));
			}
				break;
			case 4: {
				System.out.print("Enter Account Number: ");
				int accountNumber = validateAccountNumber();
				System.out.print("Enter the amount you want to withdraw: ");
				double debit = scanner.nextInt();
				System.out.println("Balance debited from account: " + accountNumber + "\nDebited: " + debit
						+ "\nAvailable balance is: " + service.withdraw(accountNumber, debit));
			}
				break;
			case 5: {
				System.out.print("Enter Your Account Number: ");
				int senderAccountNumber = validateAccountNumber();
				System.out.print("Enter Receiver Account Number: ");
				int receiverAccountNumber = validateAccountNumber();
				System.out.print("Enter the amount you want to transfer: ");
				double transferAmount = scanner.nextInt();
				System.out.println("Balance debited from account: " + senderAccountNumber + " is " + transferAmount
						+ "\nBalance credited to account: " + receiverAccountNumber + "\nAvailable balance is: "
						+ service.fundTransfer(senderAccountNumber, receiverAccountNumber, transferAmount));
			}
				break;
			case 6: {
				System.out.print("Enter Account Number: ");
				int accountNumber = validateAccountNumber();
				List<TransactionDetails> resultList = service.getTransactionDetails(accountNumber);
				System.out.println("Transaction List: ");
				for (TransactionDetails transactionDetails : resultList)
					System.out.println(transactionDetails);
			}
				break;
			case 7:
				System.out.println("Exited....");
				scanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Choice..Try again");
				break;
			}
		}
		
	}
	
	public static int validateAccountNumber() {
		int accountNumber=0;
		while(true) {
		accountNumber=scanner.nextInt();
		if(service.validateAccountNumber(accountNumber))
			return accountNumber;
		else {
		System.out.println("Account Number Doesn't Exist\nEnter Account Number Again: ");
		}
		}
	}
}
