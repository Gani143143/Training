package com.cg.service;



import java.util.ArrayList;
import java.util.List;

import com.cg.bean.AccountDetails;
import com.cg.bean.TransactionDetails;
import com.cg.dao.DataAccount;

public class ServiceAccount {
	DataAccount data=new DataAccount();
	
	public void createAccount(AccountDetails account2) {
		TransactionDetails transaction=new TransactionDetails();
		data.setAccountList(account2);
		transaction.setAccountNumber(account2.getAccountNumber());
		transaction.setCredit(account2.getAmount());
		transaction.setDebit(0);
		transaction.setAmount(account2.getAmount());
		data.setTransactionList(transaction);
	}
	
	
	public double showBalance(int accountNumber) {
		List<AccountDetails> accountList=data.getAccountList();
		
		for(AccountDetails accountDetail:accountList) {
			
			if(accountNumber==accountDetail.getAccountNumber()) {
				return accountDetail.getAmount();
			}
		}
		return 0;
		
	}
	public double deposit(int accountNumber,double credit) {
       List<AccountDetails> accountList=data.getAccountList();
		
		for(AccountDetails accountDetail:accountList) {
			
			if(accountNumber==accountDetail.getAccountNumber()) {
				TransactionDetails transaction=new TransactionDetails();
				double balance=accountDetail.getAmount();
				
				accountDetail.setAmount(balance+credit);
				transaction.setAccountNumber(accountDetail.getAccountNumber());
				transaction.setCredit(credit);
				transaction.setDebit(0);
				transaction.setAmount(accountDetail.getAmount());
				data.setTransactionList(transaction);
				return accountDetail.getAmount(); 
			}
		}
		
        return 0;		
		
	}
	public double withdraw(int accountNumber, double debit) {
       List<AccountDetails> accountList=data.getAccountList();
		
		for(AccountDetails accountDetail:accountList) {
			
			if(accountNumber==accountDetail.getAccountNumber()) {
				TransactionDetails transaction=new TransactionDetails();
				double balance=accountDetail.getAmount();
				accountDetail.setAmount(balance-debit);
				transaction.setAccountNumber(accountDetail.getAccountNumber());
				transaction.setCredit(0);
				transaction.setDebit(debit);
				transaction.setAmount(accountDetail.getAmount());
				data.setTransactionList(transaction);
				return accountDetail.getAmount(); 
			}
		}
		return 0;
	}
	public double fundTransfer(int senderAccountNumber, int receiverAccountNumber, double transferAmount) {
		double returnAmount=0;
		 List<AccountDetails> accountList=data.getAccountList();
			
			for(AccountDetails accountDetail:accountList) {
				if(senderAccountNumber==accountDetail.getAccountNumber()) {
					accountDetail.setAmount(accountDetail.getAmount()-transferAmount);
					TransactionDetails transaction=new TransactionDetails();
					transaction.setAccountNumber(accountDetail.getAccountNumber());
					transaction.setCredit(0);
					transaction.setDebit(transferAmount);
					transaction.setAmount(accountDetail.getAmount());
					data.setTransactionList(transaction);
					returnAmount= accountDetail.getAmount(); 
				}
				if(receiverAccountNumber==accountDetail.getAccountNumber()) {
					accountDetail.setAmount(accountDetail.getAmount()+transferAmount);
					TransactionDetails transaction=new TransactionDetails();
					transaction.setAccountNumber(accountDetail.getAccountNumber());
					transaction.setCredit(transferAmount);
					transaction.setDebit(0);
					transaction.setAmount(accountDetail.getAmount());
					data.setTransactionList(transaction);
					
				}
			}
			return returnAmount;
	}
	public List<TransactionDetails> getTransactionDetails(int accountNumber) {
		List<TransactionDetails> transactionList=data.getTransactionList();
		List<TransactionDetails> transactionList2=new ArrayList<>();
		for(TransactionDetails transactionDetail:transactionList) {
			if(accountNumber==transactionDetail.getAccountNumber()) {
				transactionList2.add(transactionDetail);
			}
			
		}
		return transactionList2;
	}


	public boolean validateAccountNumber(int accountNumber) {
		 List<AccountDetails> accountList=data.getAccountList();
			for(AccountDetails accountDetail:accountList) {
				if(accountNumber==accountDetail.getAccountNumber())
			return true;
			}
			return false;
	}
}
