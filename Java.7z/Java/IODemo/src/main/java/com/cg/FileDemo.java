package com.cg;

import java.io.File;
import java.io.IOException;
import java.util.Date;

public class FileDemo {
	public static void main(String[] args) {
		File file1=new File("src/main/java/com/cg/App.java");
		System.out.println(file1.exists()?" File exists":"Not exists");
		System.out.println(file1.canRead()?" readable":"Not readable");
		System.out.println("Is writable?"+file1.canWrite());
		System.out.println("Is hidden?"+file1.canExecute());
		System.out.println("Is executable?"+file1.isHidden());
		System.out.println("Path:"+file1.getPath());
		System.out.println("Abs -Path:"+file1.getAbsolutePath());
		try {
			System.out.println("CanonicalPath:"+file1.getCanonicalPath());
			System.out.println("Size"+file1.length());
			System.out.println("LastModified:"+new Date(file1.lastModified()));
			System.out.println(file1.isDirectory()?" Is a Folder":"is a file");
			File file2=new File("src/main/java/aaa");
			System.out.println("Folder created"+file2.mkdir());
			File file3=new File("src/main/java/aaa/hi.txt");
			System.out.println("File created"+file3.createNewFile());
		}
		catch(IOException e){
			e.printStackTrace();	
		}
	}
}
