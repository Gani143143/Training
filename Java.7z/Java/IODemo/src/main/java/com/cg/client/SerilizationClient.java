package com.cg.client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.cg.bean.Customer;

public class SerilizationClient {
	void serilize() {
		try(FileOutputStream fos=new FileOutputStream("serilize.txt");
				ObjectOutputStream oos=new ObjectOutputStream(fos);)
		{
			Customer customer1=new Customer(123,"priya","abc123",987654321);
			oos.writeObject(customer1);
			oos.flush();
			System.out.println("Object saved/serialized");
			
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	void deSerilize() {
		try(FileInputStream fis=new FileInputStream("serilize.txt");
				ObjectInputStream ois=new ObjectInputStream(fis);)
		{   Customer customer1=(Customer)ois.readObject();
			System.out.println(customer1);
			
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	public static void main(String[] args) {
		SerilizationClient client=new SerilizationClient();
		client.serilize();
		client.deSerilize();

	}

}
