package com.cg;

import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.IOException;
public class ConsoleIO {

	public static void main(String[] args) throws IOException {
		PrintWriter pw=new PrintWriter(System.out,true);
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		try {
			pw.println("Enter a value");
			int a=Integer.parseInt(br.readLine());
			pw.println("Enter b value");
			int b=Integer.parseInt(br.readLine());
			pw.println("Sum="+(a+b));
			pw.println("Enter name");
			String name=br.readLine();
			pw.println("welcome "+name);
			String s="Hello,welcome,to java,io,world";
		}catch(NumberFormatException e) {
			e.printStackTrace();
		}

	}

}
