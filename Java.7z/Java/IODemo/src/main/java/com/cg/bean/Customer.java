package com.cg.bean;

import java.io.Serializable;

public class Customer implements Serializable {
	private static final long serialVersionUID=1L;
	private int custID;
	private String username;
	private String password;
	private long phone;
	public Customer() {
		super();
	}
	@Override
	public String toString() {
		return "Customer [custID=" + custID + ", username=" + username + ", password=" + password + ", phone=" + phone
				+ "]";
	}
	public int getCustID() {
		return custID;
	}
	public void setCustID(int custID) {
		this.custID = custID;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public Customer(int custID, String username, String password, long phone) {
		super();
		this.custID = custID;
		this.username = username;
		this.password = password;
		this.phone = phone;
	}

}
