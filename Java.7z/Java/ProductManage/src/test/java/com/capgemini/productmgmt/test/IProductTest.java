package com.capgemini.productmgmt.test;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.productmgmt.dao.ProductDAO;
import com.capgemini.productmgmt.exception.ProductException;
/**
 * 
 * @author anudhawa
 *
 */
public class IProductTest {

	static ProductDAO pDao= null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		pDao = new ProductDAO();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		pDao = null;
	}

	@Before
	public void setUp() throws Exception {
		
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * 
	 * @throws ProductException
	 */
	
	@Test
	public void updateProductsTest() throws ProductException {
		Map<String, String> productDetails1  = new HashMap<>();
		assertNotSame(productDetails1,pDao.updateProducts("soap",10));
	}
	/**
	 * 
	 * @throws ProductException
	 */
	@Test
	public void getProductsDetailsTest() throws ProductException
	{
		Map<String, String> salesDetails1  = new HashMap<>();
		assertNotSame(salesDetails1, pDao.getProductDetails());
	}
}
