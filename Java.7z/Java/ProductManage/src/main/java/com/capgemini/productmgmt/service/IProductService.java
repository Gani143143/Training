package com.capgemini.productmgmt.service;

import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

/**
 * 
 * @author anudhawa
 *
 */

public interface IProductService {
	/**
	 * 
	 * @param Category
	 * @param hike
	 * @return
	 * @throws ProductException
	 */
	public int updateProducts(String Category, int hike) throws ProductException;
	
	/**
	 * 
	 * @return
	 * @throws ProductException
	 */
	public Map<String, Integer> getProductDetails() throws ProductException;
}
