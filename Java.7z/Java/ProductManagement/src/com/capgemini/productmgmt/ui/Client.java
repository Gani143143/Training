package com.capgemini.productmgmt.ui;

import java.util.ArrayList;
import java.util.Collection;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.productmgmt.bean.Product;
import com.capgemini.productmgmt.exception.ProductException;
import com.capgemini.productmgmt.service.IProductService;
import com.capgemini.productmgmt.service.ProductService;


public class Client {

	public static void main(String[] args) {
		IProductService service=new ProductService();
		Scanner scanner=new Scanner(System.in);
		int choice=0;
		String productName=" ";
		int productPrice=0;
		String productCategory=" ";
		int hikeRate=0;
		boolean choiceFlag=false;
		boolean updateFlag;
		do{
		try {
			System.out.println("1.Update Product Price");
			System.out.println("2.Display Product List");
			System.out.println("3.Exit");
			System.out.println("Enter your choice");
			choice=scanner.nextInt();
		switch(choice) {
		case 1: {
			boolean valid = false;

			String category = null;
			do {
				try {
					System.out.println("\nEnter the Product Category");
					category = scanner.next();
					service.isCategoryValid(category);
					valid = true;
				} catch (ProductException e) {
					System.err.println(e.getMessage());
					valid = false;
					scanner.nextLine();
				}
			} while (!valid);

			valid = false;
			int hike = 0;
			do {
				try {
					System.out.println("\nEnter hike Rate : ");
					scanner = new Scanner(System.in);
					hike = scanner.nextInt();
					service.isHikeValid(hike);
					valid = true;
				} catch (ProductException e) {
					System.err.println(e.getMessage());
					valid = false;
					scanner.nextLine();
				} catch (InputMismatchException e) {
					System.err.println("\nInput should contain only digits");
					valid = false;
					scanner.nextLine();
				}
			} while (!valid);
			//service.updateProducts(category, hike);
		}
			break;
		case 2:
			Map<String, Integer> productMap = service.getAll();
			List<String> list = new ArrayList<>();
			Collection<String> collection = productMap.keySet();
			list.addAll(collection);
			Iterator<String> iterator = list.iterator();
			System.out.println("\nProduct Details");
			while (iterator.hasNext()) {
				String key = iterator.next().toString();
				System.out.println(key + " : " + productMap.get(key));
			}
			break;
		case 3:
			
			System.exit(0);
			break;
		default:
			System.err.println("Input should be 1,2,3");
			
			break;
		}
	} catch (InputMismatchException e) {
		System.err.println("Input should contain only digits");
		
	} catch (ProductException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}while(!choiceFlag);	

	}

}
