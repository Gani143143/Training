package com.capgemini.productmgmt.dao;

import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public interface IProductDAO {
	public int updateProducts(String Category,int hike) throws ProductException;
	public Map<String, Integer> getAll() throws ProductException;
	
	

}
