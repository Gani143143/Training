package com.capgemini.productmgmt.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import com.capgemini.productmgmt.exception.ProductException;

public class ProductDAO implements IProductDAO {
	static Map<String,String> productDetails;
	static Map<String,Integer> salesDetails;
	HashMap<String, Integer> output = new HashMap<>();
	static {
		productDetails=new HashMap<>();
		productDetails.put("lux","soap");
		productDetails.put("lux","soap");
		productDetails.put("lux","soap");
		productDetails.put("lux","soap");
		productDetails.put("lux","soap");
		productDetails.put("lux","soap");
		
		salesDetails=new HashMap<>();
		salesDetails.put("lux", 100);
		salesDetails.put("lux", 50);
		salesDetails.put("lux", 70);
		salesDetails.put("lux", 10000);
		salesDetails.put("lux", 23000);
		salesDetails.put("lux", 100);
		salesDetails.put("lux", 60);
	}
	

	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		List<String> categoryList=new ArrayList();
		Collection<String> collection=productDetails.keySet();
		categoryList.addAll(collection);
		Iterator<String> iterator=categoryList.iterator();
		while(iterator.hasNext()) {
			String key=iterator.next().toString();
			String value=productDetails.get(key);
			if(value.equalsIgnoreCase(Category)) {
				int o=salesDetails.get(key);
				int h1=(hike*o)/100;
				int h=o+h1;
				salesDetails.replace(key,o,h);
			}
		}
		return hike;
		
	}

	@Override
	public Map<String, Integer> getAll() throws ProductException {
		
		return salesDetails;
	}

}
