package com.capgemini.productmgmt.service;

import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public interface IProductService {
	public int updateProducts(String Category,int hike) throws ProductException;
	
	public boolean isCategoryValid(String category) throws ProductException;
	public boolean isHikeValid(int hike) throws ProductException;
	public Map<String, Integer> getAll() throws ProductException;

}
