package com.capgemini.productmgmt.service;

import java.util.Map;

import com.capgemini.productmgmt.dao.IProductDAO;
import com.capgemini.productmgmt.dao.ProductDAO;
import com.capgemini.productmgmt.exception.ProductException;

public class ProductService implements IProductService {
	IProductDAO dao=new ProductDAO();

	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		
		return dao.updateProducts(Category,hike);
	}

	

	@Override
	public boolean isCategoryValid(String category) throws ProductException {
		boolean valid=false;
		if(category.equals("soap") || category.equals("paste") || category.equals("electronics") || category.equals("cosmatics")) {
			valid=true;
		}
		else {
			//throw new ProductException("Category as mentioned");
			valid=false;
		}
		return valid;
	}

	@Override
	public boolean isHikeValid(int hike) throws ProductException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Map<String, Integer> getAll() throws ProductException{
		// TODO Auto-generated method stub
		return dao.getAll();
	}

	

	
	

}
