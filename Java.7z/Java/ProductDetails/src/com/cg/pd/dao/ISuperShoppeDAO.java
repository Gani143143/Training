package com.cg.pd.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pd.bean.Product;
import com.cg.pd.bean.Supplier;

public interface ISuperShoppeDAO {
	 
	Map<Integer, Product> productList = new HashMap<>();
	Map<Integer, Supplier> supplierList = new HashMap<>();
	public int addProduct(Product product);
	public int addSupplier(Supplier sup);
	public HashMap<Integer,Product> getAllProducts();
	public HashMap<Integer,Supplier> getAllSuppliers();
}
