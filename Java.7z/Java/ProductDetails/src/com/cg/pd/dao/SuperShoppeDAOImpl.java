package com.cg.pd.dao;

import java.util.HashMap;

import com.cg.pd.bean.Product;
import com.cg.pd.bean.Supplier;

public class SuperShoppeDAOImpl implements ISuperShoppeDAO {
	/*HashMap<Integer,Product> products;
	 HashMap<Integer,Supplier> suppliers;*/
	@Override
	public int addProduct(Product product) {
		Product prod = productList.put(product.getProductId(), product);
		return product.getProductId();
	}

	@Override
	public int addSupplier(Supplier sup) {
		//why object of supplier is created
		Supplier supp = supplierList.put(sup.getSupplierId(), sup);
		return sup.getSupplierId();
	}

	@Override
	public HashMap<Integer, Product> getAllProducts() {
		
		return (HashMap<Integer, Product>) productList;
	}

	@Override
	public HashMap<Integer, Supplier> getAllSuppliers() {
		
		return (HashMap<Integer, Supplier>) supplierList;
	}

}
