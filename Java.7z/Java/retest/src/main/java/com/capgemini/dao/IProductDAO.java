package com.capgemini.dao;

import java.util.List;

import com.capgemini.bean.Product;



public interface IProductDAO {
	
	List<Product> getAllProducts();

}
