package com.capgemini.bean;

public class Product  implements Comparable<Product>{
	
	private int id;
	private int sequence;
	private String name;
	private double price;
	private long isbnnumber;
	
	
	

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}




	public Product(int id, int sequence, String name, double price, long isbnnumber) {
		super();
		this.id = id;
		this.sequence = sequence;
		this.name = name;
		this.price = price;
		this.isbnnumber = isbnnumber;
	}
  



	public int getId() {
		return id;
	}




	public void setId(int id) {
		this.id = id;
	}




	public int getSequence() {
		return sequence;
	}




	public void setSequence(int sequence) {
		this.sequence = sequence;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public double getPrice() {
		return price;
	}




	public void setPrice(double price) {
		this.price = price;
	}




	public long getIsbnnumber() {
		return isbnnumber;
	}




	public void setIsbnnumber(long isbnnumber) {
		this.isbnnumber = isbnnumber;
	}
	




	@Override
	public String toString() {
		return "Product [id=" + id + ", sequence=" + sequence + ", name=" + name + ", price=" + price + ", isbnnumber="
				+ isbnnumber + "]";
	}




	public int compareTo(Product p) {
		
		if(this.id>p.id)
			return 1;
		else if(this.id<p.id)
			return -1;
		else 
			return 0;
		
		
	}

}
