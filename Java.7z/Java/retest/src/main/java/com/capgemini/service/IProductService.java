package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Product;



public interface IProductService {
	
	public List<Product> getAllProducts();

}
