package com.cg.fms.ui;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.cg.fms.bean.Feedback;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.FeedbackService;
import com.cg.fms.service.IFeedbackService;

public class Client {

	public static void main(String[] args) {
		IFeedbackService service = new FeedbackService();
		Scanner scanner = null;
		int choice = 0;
		String teacherName = " ";
		int rating = 0;
		String topic = " ";
		boolean choiceFlag = false;
		boolean nameFlag = false;
		boolean ratingFlag = false;
		boolean topicFlag = false;
		boolean optionFlag = false;
		try {
			do {
				System.out.println("1.Add Feedback");
				System.out.println("2.Print Feedback Report");
				System.out.println("3.Exit");
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					do {
						try {
							scanner = new Scanner(System.in);
							System.out.println("Enter Teacher Name");
							teacherName = scanner.next();
							service.isNameValid(teacherName);
							nameFlag = true;
						} catch (FMSException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!nameFlag);
					do {
						try {
							scanner = new Scanner(System.in);
							System.out.println("Enter Rating");
							rating = scanner.nextInt();
							service.isRatingValid(rating);
							ratingFlag = true;
						} catch (FMSException e) {
							ratingFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!ratingFlag);
					do {
						try {
							scanner = new Scanner(System.in);
							System.out.println("Enter Topic");
							topic = scanner.nextLine();
							service.isTopicValid(topic);
							topicFlag = true;
						} catch (FMSException e) {
							topicFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!topicFlag);
				
					System.out.println("Feedback Added");
					Map<String, Integer> map = new HashMap<String, Integer>();
					Feedback feed = new Feedback(teacherName, rating, topic);
					map = service.addFeedbackDetails(teacherName, rating, topic);
					System.out.println(map);
					
					break;

				case 2:
					Map<String, Integer> feedbackMap = service.getFeedbackReport();
					System.out.println(feedbackMap);

					break;
				case 3:
					System.out.println("Great to see you bye!");
					System.exit(0);
					break;

				default:
					System.err.println("Choice should be only 1,2 and 3 only");
					break;
				}
				
				do {
					System.out.println("Do you want to continue yes/no");
					scanner = new Scanner(System.in);
					String option = scanner.nextLine();
					optionFlag = false;
					if (option.equalsIgnoreCase("yes")) {
						optionFlag = true;
						break;
					} else if (option.equalsIgnoreCase("no")) {
						optionFlag = false;
						System.out.println("Good Bye!"); 
						System.exit(0);
					} else {
						System.err.println("Enter only yes or no");
						optionFlag = false;
						continue;
					}

				} while (!optionFlag);
			} while (!choiceFlag);
		} catch (InputMismatchException e) {
			System.err.println("Choice should be only 1,2 and 3 only");
		}finally {
			scanner.close();
		}
	}

}
