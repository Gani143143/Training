package com.cg.fms.exception;

public class FMSException extends Exception{

	public FMSException(String message) {
		super(message);
		
	}

}
