package com.cg.fms.service;

import java.util.Map;

import com.cg.fms.exception.FMSException;

public interface IFeedbackService {

	boolean isNameValid(String teacherName) throws FMSException;

	boolean isRatingValid(int rating) throws FMSException;

	boolean isTopicValid(String topic) throws FMSException;

	Map<String, Integer> addFeedbackDetails(String teacherName, int rating, String topic);

	Map<String, Integer> getFeedbackReport();

}
