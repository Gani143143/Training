package com.capgemini.product.dao;


import java.util.HashMap;
import java.util.Map;

import com.capgemini.product.Exception.LCException;
import com.capgemini.product.bean.Product;
import com.capgemini.product.utility.ProductDB;

public class LocalCurrencyDaoImpl implements LocalCurrencyDao {
	Map<Integer, Product> map=ProductDB.getProductList();
	 
	@Override
	public int addProduct(Product product) throws LCException {
		//Product newItem=new Product(111,3000,50,"Amber");
		
	
		int randomId=(int) (Math.random() * 1000);
	        
		product.setProductId(randomId);
		map.put(randomId, product);
		//map.replace(111, newItem);
		return randomId;
	}

	@Override
	public double getPriceInINR(double productPrice,int productQuantity) throws LCException {
		double dollarValue=75;
		double orderAmount= (productPrice * dollarValue) * productQuantity;
		return orderAmount;
	}

	@Override
	public double getConversionCharge(double productPrice) throws LCException {
		int conversionCharge = (int) (0.015 * productPrice);
		return conversionCharge;
	}

	@Override
	public Map<Integer, Product> getAllProducts() throws LCException {
		
		return (Map<Integer, Product>) ProductDB.getProductList();
	}

	@Override
	public boolean updateProduct(int id,Product products) throws LCException {
		Product result=map.replace(id, products);
		//System.out.println(result);
		if(result==null)
			return true;
		
		return false;
	}

	@Override
	public boolean deleteItem(int id) {
		Product status=map.remove(id);
		System.out.println(status);
		if(status!=null)
		return true;
		else
		return false;
	}

	@Override
	public Product viewById(int custId) {
		Product view=map.get(custId);
		return view;
	}

	

}
