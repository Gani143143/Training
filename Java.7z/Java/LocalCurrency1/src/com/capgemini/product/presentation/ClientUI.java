package com.capgemini.product.presentation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.product.Exception.LCException;
import com.capgemini.product.bean.Product;
import com.capgemini.product.service.LocalCurrencyService;
import com.capgemini.product.service.LocalCurrencyServiceImpl;

/**
 * 
 * @author anjyerra
 *@version 1.0
 *ClientUI class takes user input
 */
public class ClientUI {
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {

		System.out.println("*************Welecome to Currency Conversion App******************");

		LocalCurrencyService service = new LocalCurrencyServiceImpl();

		Scanner scanner = null;
		int choice = 0;
		double productPrice = 0;
		int productQuantity = 0;
		int generatedId = 0;
		int productId=0;
		String productName = "";
		boolean choiceFlag = false;
		boolean nameFlag = false;
		boolean priceFlag = false;
		boolean quantityFlag = false;
		boolean optionFlag = false;
		boolean updateFlag = false;

		try {
			do {
				System.out.println("1. Add Product Details");
				System.out.println("2. Update Product Details");
				System.out.println("3. Delete Product Details");
				System.out.println("4. Show Product Details by ID");
				System.out.println("5. Show All Products");
				System.out.println("6. Exit");
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				choice = scanner.nextInt();
				switch (choice) {
				case 1: {
					do {
						
						try {
							scanner=new Scanner(System.in);
							System.out.println("Enter Product Name");
							productName = scanner.nextLine();
							service.isNameValid(productName);
							nameFlag = true;
						} catch (LCException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}

					} while (!nameFlag);

					do {
						System.out.println("Enter Product Price");

						try {
							productPrice = scanner.nextDouble();
							service.isPriceValid(productPrice);
							priceFlag = true;
						} catch (LCException e) {
							priceFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!priceFlag);

					do {
						System.out.println("Enter Product Quantity");

						try {scanner = new Scanner(System.in);
							productQuantity = scanner.nextInt();
							service.isQuantityValid(productQuantity);
							quantityFlag = true;
						} catch (LCException e) {
							quantityFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!quantityFlag);
				}

					Product product = new Product( productPrice, productQuantity, productName);

					try {
						generatedId = service.addProduct(product);
						double orderAmount = service.getPriceInINR(productPrice, productQuantity);
						double conversionCharge=service.getConversionCharge(productPrice);
						System.out.println("Price per Product is:" + productPrice);
						System.out.println("Conversion Charge is:" + conversionCharge + " per product");
						System.out.println("Product Added Successfully with Id: " + generatedId + "\nWith Total Amount: "
								+ orderAmount);
						
					} catch (LCException e) {
						System.err.println(e.getMessage());
					}
					break;

				case 2:{
					
					System.out.println("Enter Product Id to update");
					productId=scanner.nextInt();
					scanner.nextLine();
					System.out.println("Enter Product Name");
					productName=scanner.nextLine();
					System.out.println("Enter Product Price");
					productPrice=scanner.nextDouble();
					System.out.println("Enter Product Quantity");
					productQuantity=scanner.nextInt();
					Product products=new Product(productId, productPrice, productQuantity, productName);
					try {
						
						boolean status=service.updateProduct(productId,products);
						if(!status)
						System.out.println("Updated Successfully");
						else
							System.out.println("Not found");
						updateFlag=true;
					} catch (LCException e) {
						updateFlag=false;
						System.err.println(e.getMessage());
					}
					}
					break;
				case 3:{  
					 System.out.println("Enter id to remove:");
					 int id=scanner.nextInt();
					 boolean result=service.delete(id);
					  if(result)
						  System.out.println("Deleted successfully");
					  else
						  System.out.println("Product not found");
					}
					
					break;
				case 4:{
					System.out.println("Enter customer id to delete");
				      int custId=scanner.nextInt();
				      Product c=service.viewById(custId);
				      System.out.println(c);
					
				}					
					break;
				case 5:{
					try {
						List<Product> products=service.getAllProducts();
						Iterator<Product> iterator = products.iterator();
						while (iterator.hasNext()) {
							System.out.println(iterator.next());
							
						}
					} catch (LCException e) {
						System.err.println(e.getMessage());
					}
				}
					
					break;
				case 6:
					System.out.println("Great to see you bye!");
					System.exit(0);
					break;
				default:
					System.err.println("Enter 1, or 3 only");
					break;
				}

				do {
					System.out.println("Do you want to continue yes/no");
					scanner = new Scanner(System.in);
					String option = scanner.nextLine();
					optionFlag = false;
					if (option.equalsIgnoreCase("yes")) {
						optionFlag = true;
						break;
					} else if (option.equalsIgnoreCase("no")) {
						optionFlag = false;
						System.out.println("Good Bye!"); 
						System.exit(0);
					} else {
						System.err.println("Enter only yes or no");
						optionFlag = false;
						continue;
					}

				} while (!optionFlag);
			} while (!choiceFlag);
		} catch (InputMismatchException e) {
			System.err.println("Please enter digits only");
		}finally {
			scanner.close();
		}
	}

}
