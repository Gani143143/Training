package com.capgemini.product.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.product.Exception.LCException;
import com.capgemini.product.bean.Product;
import com.capgemini.product.dao.LocalCurrencyDao;
import com.capgemini.product.dao.LocalCurrencyDaoImpl;

public class DaoTest {
	
	static LocalCurrencyDao dao=null;
	Product product;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		dao=new LocalCurrencyDaoImpl();
		
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		dao=null;
	}

	@Before
	public void setUp() throws Exception {
		product=new Product(2,2333,2,"jjj");
		
	}

	@After
	public void tearDown() throws Exception {
		product=null;
	}

	@Test
	public void testAddProduct() {
		try {
			assertTrue(dao.addProduct(product)>0);
		} catch (LCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}

	@Test
	public void testGetPriceInINR() {
		double total=100*2*75;
		try {
			assertEquals((int)total, (int)dao.getPriceInINR(100, 2));
		} catch (LCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetConversionCharge() {
		double convert=0.015*100;
		try {
			assertEquals((int)convert,(int) dao.getConversionCharge(100));
		} catch (LCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetAllProducts() {
		try {
			assertTrue(dao.getAllProducts().size()> 0);
		} catch (LCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
