package com.capgemini.product.utility;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.product.bean.Product;

public class ProductDB {
	
	static Map<Integer, Product> productList=new HashMap<>();
	
	static {
		
		productList.put(111,new Product(111,5, 2000, "PenA"));
		productList.put(222,new Product(222,5, 3000, "PenB"));
		productList.put(333,new Product(333,5, 4000, "PenC"));
		productList.put(444,new Product(444,5, 5000, "PenD"));
		productList.put(555,new Product(555,5, 6000, "PenE"));
	}

	public static Map<Integer, Product> getProductList() {
		return productList;
	}

	public static void setProductList(Map<Integer, Product> productList) {
		ProductDB.productList = productList;
	}
	
	
}
