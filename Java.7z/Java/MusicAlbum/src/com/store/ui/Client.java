package com.store.ui;

import java.util.Scanner;

import com.store.bean.Album;
import com.store.exception.InvalidAlbumIdException;
import com.store.service.AlbumService;
import com.store.service.AlbumServiceImp;

public class Client {
	static Scanner scanner=new Scanner(System.in);
	static Album album=new Album();
	static AlbumService albumservice=new  AlbumServiceImp();
	public static void main(String args[]) {
		int response;
		while(true) {
			System.out.println("1. Add Music Album");
			System.out.println("2. Find Music Album");
			System.out.println("3. Exit");
			response=scanner.nextInt();
			switch(response) {
			case 1: addMusicAlbum();
			
			break;
			case 2: findAlbumById();
			
			break;
			case 3: System.out.println("Thank You !! visit again");
			System.exit(0);
			}
		}
	}
	
	private static void addMusicAlbum() {
		// TODO Auto-generated method stub
		System.out.println("enter the title");
		album.setTitle(scanner.next());
		System.out.println("Enter artist");
		album.setArtist(scanner.next());
		System.out.println("enter price");
		album.setPrice(scanner.nextDouble());
		System.out.println("enter rating");
		album.setRating(scanner.nextDouble());
		try {
			System.out.println("Album stored with the id:"+albumservice.saveAlbum(album));
		}catch(InvalidAlbumIdException iAIE) {
			System.out.println("Album cant be saved");
		}
	}
		private static void findAlbumById() {
			// TODO Auto-generated method stub
			System.out.println("enter the album id");
			int albumId=scanner.nextInt();
			try {
				
				Album obj= albumservice.findById(albumId);
				System.out.println("Title:"+obj.getTitle()+"\n"+"Artist:"+obj.getArtist()+"\n"+"Price:"+obj.getPrice()+"\n"+"Rating:"+obj.getRating());
		}
			catch(InvalidAlbumIdException e ) {
			System.err.println("oops: No album found with Id");
		}
		
		
	}
	

}
