package com.store.dao;

import com.store.bean.Album;
import com.store.exception.InvalidAlbumIdException;

public interface AlbumDao {

	 int persist(Album album) throws InvalidAlbumIdException;
		// TODO Auto-generated method stub
		
	Album find(int id) throws InvalidAlbumIdException;
	}
	


