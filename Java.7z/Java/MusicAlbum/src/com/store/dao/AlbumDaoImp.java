package com.store.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.store.bean.Album;
import com.store.exception.InvalidAlbumIdException;

public class AlbumDaoImp implements AlbumDao{
	private Map<Integer,Album> albums=new HashMap<>();
	private Random random=new Random();
	private int albumId;
	
	@Override
	public int persist(Album album) throws InvalidAlbumIdException {
		// TODO Auto-generated method stub
		albumId=Math.abs(random.nextInt());
		albums.put(albumId, new Album(album.getTitle(),album.getArtist(),album.getPrice(),album.getRating()));
		return albumId;
	}
	
	@Override
	public Album find(int id) throws InvalidAlbumIdException {
		// TODO Auto-generated method stub
		if(albums.containsKey(id)) {
			return albums.get(id);
		}
		else {
			throw new  InvalidAlbumIdException("album does not exist");
		}
		
	}

}
