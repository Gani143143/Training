package com.store.service;

import com.store.bean.Album;
import com.store.dao.AlbumDao;
import com.store.dao.AlbumDaoImp;
import com.store.exception.InvalidAlbumIdException;

public class AlbumServiceImp implements AlbumService{
	AlbumDao albumdao=new AlbumDaoImp();

	@Override
	public int saveAlbum(Album album) throws InvalidAlbumIdException {
		// TODO Auto-generated method stub
		
		return albumdao.persist(album);
	}

	@Override
	public Album findById(int id) throws InvalidAlbumIdException {
		// TODO Auto-generated method stub
		return albumdao.find(id);
	}

}
