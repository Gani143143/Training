package com.store.service;

import com.store.bean.Album;
import com.store.exception.InvalidAlbumIdException;

public interface AlbumService {
int saveAlbum(Album album) throws InvalidAlbumIdException;
Album findById(int id) throws InvalidAlbumIdException;
}
