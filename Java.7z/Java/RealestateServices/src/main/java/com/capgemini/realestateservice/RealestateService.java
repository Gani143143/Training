package com.capgemini.realestateservice;

import java.util.ArrayList;
import java.util.Map;

import com.capgemini.realestatebean.RealestateBean;
import com.capgemini.registrationexception.RegistrationException;

public interface RealestateService {
RealestateBean registerFlat(RealestateBean flat) throws RegistrationException;
ArrayList<Integer> getAllOwnerIds() throws RegistrationException;
void validateArea(int area);
Map<Integer, RealestateBean> getFlatDetails();
}
