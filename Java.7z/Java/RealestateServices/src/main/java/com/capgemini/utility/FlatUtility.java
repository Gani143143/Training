package com.capgemini.utility;

import java.util.Map;
import java.util.TreeMap;

import com.capgemini.realestatebean.FlatOwner;

public class FlatUtility {
	 public static Map<Integer, FlatOwner> owners=new TreeMap<>();
	static {
		owners.put(1,new FlatOwner(1, "karthik",91002104));
		owners.put(3,new FlatOwner(3, "gayatri",91002103));
		owners.put(2,new FlatOwner(2, "shanmuk",91002101));
	}
	
}
