package com.capgemini.realestatebean;

public class RealestateBean {
private int flatId;

private int flatType;
private int flatArea;
private  double rentAmount;
private double depositAmount;
public RealestateBean() {
	super();
}
public RealestateBean(int flatId, int onwerId, int flatType, int flatArea, long rentAmount, long depositAmount) {
	super();
	this.flatId = flatId;
	this.flatType = flatType;
	this.flatArea = flatArea;
	this.rentAmount = rentAmount;
	this.depositAmount = depositAmount;
}
public RealestateBean(int type, int area, double rent, double deposit) {
	this.flatType = type;
	this.flatArea = area;
	this.rentAmount = rent;
	this.depositAmount = deposit;
}
public int getFlatId() {
	return flatId;
}
public void setFlatId(int flatId) {
	this.flatId = flatId;
}


public int getFlatType() {
	return flatType;
}
public void setFlatType(int flatType) {
	this.flatType = flatType;
}
public int getFlatArea() {
	return flatArea;
}
public void setFlatArea(int flatArea) {
	this.flatArea = flatArea;
}
public double getRentAmount() {
	return rentAmount;
}
public void setRentAmount(long rentAmount) {
	this.rentAmount = rentAmount;
}
public double getDepositAmount() {
	return depositAmount;
}
public void setDepositAmount(long depositAmount) {
	this.depositAmount = depositAmount;
}
@Override
public String toString() {
	return "\n flatId=" + flatId + ",  flatType=" + flatType + ", flatArea="
			+ flatArea + ", rentAmount=" + rentAmount + ", depositAmount=" + depositAmount;
}

}

