package com.capgemini.registrationexception;

public class RegistrationException extends Exception {
public RegistrationException(String message) {
	super(message);
}
}
