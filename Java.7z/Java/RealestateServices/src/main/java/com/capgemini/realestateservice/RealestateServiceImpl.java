package com.capgemini.realestateservice;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import javax.xml.ws.FaultAction;

import com.capgemini.realestatebean.RealestateBean;
import com.capgemini.registrationdao.IRegistrationDao;
import com.capgemini.registrationdao.RegistrationDaoImpl;
import com.capgemini.registrationexception.RegistrationException;
import com.capgemini.utility.FlatUtility;

public class RealestateServiceImpl implements RealestateService {
   IRegistrationDao dao=new RegistrationDaoImpl();
	@Override
	public RealestateBean registerFlat(RealestateBean flat) throws RegistrationException {
		double randomNumber = Math.random() * 1000;

		int generatedId = (int) randomNumber;
		      flat.setFlatId(generatedId);
		return dao.registerFlat(flat);
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() throws RegistrationException {
	
		return dao.getAllOwnerIds();
	}

	@Override
	public void validateArea(int area) {
		
	}

	@Override
	public Map<Integer, RealestateBean> getFlatDetails() {
		return dao.getFlatDetails();
	}

}
