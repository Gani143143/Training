package com.capgemini.java.feedback.presentation;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.java.feedback.bean.FeedBack;
import com.capgemini.java.feedback.exceptions.FeedbackException;
import com.capgemini.java.feedback.service.FeedbackService;

public class MainUI {
	static FeedbackService service=new FeedbackService();
	static Scanner scanner=new Scanner(System.in);
	static void addFeedback()
	{
		String tname=null;
		int rating=0;
		String subname=null;
		System.out.println("enter teacher name");
		tname=scanner.next();
		 boolean subjectFlag=false;
		do {
		System.out.println("enter subject name");
		subname=scanner.next();
		subjectFlag=true;
		if(!(subname.equals("maths")||subname.equals("english")))
		{
			try {
				throw new FeedbackException("enter crtly");
			} catch (FeedbackException e) {
				subjectFlag=false;
				System.err.println(e.getMessage());
			}
		}
		}while(!subjectFlag);
		System.out.println("enter rating");
		rating=scanner.nextInt();
		System.out.println("Feedback added");
		Map<String, Integer> map=new HashMap<String, Integer>();
		FeedBack feed=new FeedBack(tname, rating, subname);
		map=service.addFeedbackDetails(tname, rating, subname);
		System.out.println(map);
		
	}
	
	static void  printFeedBack()
	{
		Map<String, Integer> feedbackMap=service.getFeedbackReport();
		System.out.println(feedbackMap);
	}
public static void main(String[] args) {
	boolean choiceFlag = false;
	String continueChoice;
	boolean continueValue = false;

	do {
		try {
			System.out.println("1.add Feedback \n 2.print feedbackreport \n 3.Exit");
			int choice = scanner.nextInt();
			switch (choice) {
			
			case 1:
				addFeedback();
				break;
			case 2:
			printFeedBack();
				break;
			case 3:System.out.println("thank you");
			System.exit(0);
			default:
				System.out.println("choice shld be 1,2 or 3");
				break;
			}

		} catch (InputMismatchException e) {
			choiceFlag = false;
			System.err.println("input should contains digits");
		}
		do {
			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();
			if (continueChoice.equalsIgnoreCase("yes")) {
				continueValue = true;
				break;
			} else if (continueChoice.equalsIgnoreCase("no")) {
				System.out.println("thank you");
				continueValue = false;
				break;
			} else {
				System.out.println("enter yes or no");
				continueValue = false;
				continue;
			}
		} while (!continueValue);

	} while (continueValue);
	//System.out.println("end");

	scanner.close();

}

}








