package com.capgemini.java.feedback.dao;

import java.util.HashMap;
import java.util.Map;

public class FeedbackDAO implements IFeedbackDAO {
static	Map<String, Integer> mathFeedBackMap=new HashMap<String, Integer>();
static	Map<String, Integer> englishFeedBackMap=new HashMap<String, Integer>();
	static Map<String, Integer> feedbackMap=new HashMap<String, Integer>();

	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
		if(subject.equalsIgnoreCase("math")) {
			if(feedbackMap.containsKey(name)) {
				if(rating<feedbackMap.get(name))
				{
					feedbackMap.put(name, feedbackMap.get(name));
				}
				else {
					feedbackMap.put(name, rating);
				}
			}
			else {
				feedbackMap.put(name, rating);
			}
			mathFeedBackMap.put(name, rating);
			return mathFeedBackMap;
		}
		else {
			if(feedbackMap.containsKey(name)) {
				if(rating<feedbackMap.get(name)) {
					feedbackMap.put(name, feedbackMap.get(name));
				}
				else {
					feedbackMap.put(name, rating);
				}
			}
			else {
				feedbackMap.put(name, rating);
			}
			englishFeedBackMap.put(name, rating);
			return englishFeedBackMap;
		}
		
	}

	public Map<String, Integer> getFeedbackReport() {
		
		return feedbackMap;
	}

}
