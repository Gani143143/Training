package com.cg.presentation;

import java.util.Collections;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.Product;
import com.cg.dao.ProductDao;
import com.cg.dao.ProductDaoImpl;
import com.cg.utility.SortByName;
import com.cg.utility.SortByPid;
import com.cg.utility.SortByPrice;

/**
 * @author gkorada
 *
 */
public class MainUI {

	public static void main(String[] args) {
		ProductDao dao=new ProductDaoImpl();
		Scanner scanner = null;
		int choice = 0;
		boolean optionFlag = false;
		boolean choiceFlag = false;
		try {
			do {
				scanner = new Scanner(System.in);
				List<Product> productlist = dao.getAllProducts();
				for (Product product : productlist) {
					System.out.println(product);
				}
				System.out.println("Enter your choice");
				System.out.println("1.SortByName\n2.SortByPrice\n3.SortByPid\n4.AddProduct\n5.Delete\n6.Display\n7.Exit");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					List<Product> productlistbyname = dao.getAllProducts();
					Collections.sort(productlistbyname, new SortByName());
					display(productlistbyname);
					break;
				case 2:
					List<Product> productlistbyprice = dao.getAllProducts();
					Collections.sort(productlistbyprice, new SortByPrice());
					display(productlistbyprice);
					break;
				case 3:
					List<Product> productlistbypid = dao.getAllProducts();
					Collections.sort(productlistbypid, new SortByPid());
					display(productlistbypid);
					break;
				case 4: {
					System.out.println("Enter product id: ");
					int productId = scanner.nextInt();
					scanner.nextLine();
					System.out.println("Enter product name: ");
					String productName = scanner.nextLine();
					System.out.println("Enter product price: ");
					int price = scanner.nextInt();
					Product product = new Product(productId, productName, price);
					HashMap<Integer, Product> addProduct = dao.addProducts(product);
					Iterator<Product> iterator=addProduct.values().iterator();
					while(iterator.hasNext()) {
						Product product1=iterator.next();
						System.out.println(product1);
					}
				}
					break;	
				case 5: {
					System.out.println("Enter product id you want to delete: ");
					int productId = scanner.nextInt();
					HashMap<Integer, Product> deletedMap = dao.deleteProduct(productId);
					Iterator<Product> iterator=deletedMap.values().iterator();
					while(iterator.hasNext()) {
						Product product1=iterator.next();
						System.out.println(product1);
					}
				}
					break;
				case 6:{
					List<Product> productListByName = dao.getAllProducts();
					display(productListByName);
				}break;	
				case 7:
					System.out.println("Great to see you bye!");
					System.exit(0);
					break;
				default:
					System.err.println("Enter 1, or 4 only");
					break;	
				}
				do {
					System.out.println("Do you want to continue yes/no");
					scanner = new Scanner(System.in);
					String option = scanner.nextLine();
					optionFlag = false;
					if (option.equalsIgnoreCase("yes")) {
						optionFlag = true;
						break;
					} else if (option.equalsIgnoreCase("no")) {
						optionFlag = false;
						System.out.println("Good Bye!");
						System.exit(0);
					} else {
						System.err.println("Enter only yes or no");
						optionFlag = false;
						continue;
					}

				} while (!optionFlag);
			} while (!choiceFlag);
		} catch (InputMismatchException e) {
			System.err.println("Enter only digits");
		}
	}
	static void display(List<Product>productlist) {
		for(Product product : productlist) {
			System.out.println(product);
		}
	}

}
