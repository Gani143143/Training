package com.cg.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.bean.Product;

public interface ProductDao {
	public List<Product>getAllProducts();

	

	public HashMap<Integer, Product> addProducts(Product product);



	public HashMap<Integer, Product> deleteProduct(int productId);

}
