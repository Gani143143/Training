package com.cg.mainui;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


import com.cg.bean.GSTBean;
import com.cg.exception.GSTException;
import com.cg.service.GSTServiceImpl;
import com.cg.service.IGSTService;

public class Main {

	public static void main(String[] args) {
		IGSTService service=new GSTServiceImpl();
		Scanner scanner=null;
		int choice=0;
		String productName="";
		int productWeight=0;
		int distance=0;
		int generatedId=0;
		boolean choiceFlag=false;
		boolean nameFlag=false;
		boolean weightFlag=false;
		boolean distanceFlag=false;
		boolean optionFlag=false;
	
		try {
			do {
				System.out.println("1.Add product");
				System.out.println("2.Get all products");
				System.out.println("3.Exit");
				scanner=new Scanner(System.in);
				System.out.println("Enter your choice");
				choice=scanner.nextInt();
				switch (choice) {
				case 1:{
					do {
						try {
							scanner=new Scanner(System.in);
							System.out.println("Enter productName");
							productName=scanner.nextLine();
							service.isNameValid(productName);
							nameFlag=true;
						} catch (GSTException e) {
							nameFlag=false;
							System.err.println(e.getMessage());
						}
					} while (!nameFlag);
					do {
						try {
							scanner=new Scanner(System.in);
							System.out.println("Enter productWeight");
							productWeight=scanner.nextInt();
							service.isWeightValid(productWeight);
							weightFlag=true;
						} catch (GSTException e) {
							System.err.println(e.getMessage());
						}
					} while (!weightFlag);
					do {
						try {
							scanner=new Scanner(System.in);
							System.out.println("Enter distance");
							distance=scanner.nextInt();
							service.isDistanceValid(distance);
							distanceFlag=true;
						} catch (GSTException e) {
							System.err.println(e.getMessage());
						}
					} while (!distanceFlag);
				}
					GSTBean product=new GSTBean(productName,productWeight,distance);
					try {
						generatedId=service.addProduct(product);
						double transportCharges=service.getTransportCharge(distance,productWeight);
						double GST=service.getGST(transportCharges);
						System.out.println("Product added with id is:"+generatedId);
						System.out.println("Transport charges for the product is:"+transportCharges);
						System.out.println("GST for the product is:"+GST);
					} catch (GSTException e) {
						System.err.println(e.getMessage());
					}
					break;
				case 2:{
					try {
						List<GSTBean> products=service.getAllProducts();
						Iterator<GSTBean> iterator = products.iterator();
						while (iterator.hasNext()) {
							System.out.println(iterator.next());
							
						}
					} catch (GSTException e) {
						System.err.println(e.getMessage());
					}
				}
					break;
				case 3:
					System.out.println("Great to see you bye!");
					System.exit(0);
					break;	

				default:
					System.err.println("Enter 1,2 or 3 only");
					break;
				}
				do {
					System.out.println("Do you want to continue yes/no");
					scanner = new Scanner(System.in);
					String option = scanner.nextLine();
					optionFlag = false;
					if (option.equalsIgnoreCase("yes")) {
						optionFlag = true;
						break;
					} else if (option.equalsIgnoreCase("no")) {
						optionFlag = false;
						System.out.println("Good Bye!"); 
						System.exit(0);
					} else {
						System.err.println("Enter only yes or no");
						optionFlag = false;
						continue;
					}

				} while (!optionFlag);	
			} while (!choiceFlag);
		} catch (InputMismatchException e) {
			System.err.println("Please enter digits only");
			
		}finally {
			scanner.close();
		}
	}

}
