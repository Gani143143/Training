package com.cg.dao;

import java.util.HashMap;
import java.util.Map;


import com.cg.bean.GSTBean;
import com.cg.exception.GSTException;
import com.cg.utility.ProductDetails;

public class GSTDaoImpl implements IGSTDao {
	Map<Integer, GSTBean> map=ProductDetails.getProductList();

	@Override
	public int addProduct(GSTBean product) throws GSTException{
		int generatedId=(int) (Math.random()*1000);
		product.setProductId(generatedId);
		map.put(generatedId,product);
		return generatedId;
	}

	@Override
	public double getTransportCharge(int distance, int productWeight) throws GSTException{
		double transportCharges=2*distance*productWeight;
		return transportCharges;
	}

	@Override
	public double getGST(double transportCharges) {
		double CGST=(transportCharges*3.5)/100;
		double SGST=(transportCharges*3.5)/100;
		double GST=CGST+SGST;
		return GST;
	}

	@Override
	public Map<Integer, GSTBean> getAllProducts() throws GSTException {
		return ProductDetails.getProductList();
	}

	
}
