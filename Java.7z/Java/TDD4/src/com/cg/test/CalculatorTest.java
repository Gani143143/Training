package com.cg.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.service.Calculator;

public class CalculatorTest {
	
	static Calculator calc;
	int a,b;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		calc=new Calculator();
		System.out.println("Beforeclass");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		calc=null;
		System.out.println("Afterclass");
	}

	@Before
	public void setUp() throws Exception {
		a=10;
		b=2;
		System.out.println("Before");
	}
	@After
	public void tearDown() throws Exception {
		System.out.println("After");
	}
	@Test
	public void testAdd() {
		System.out.println("add");
		assertEquals(12,calc.add(a, b));
	}
	@Test
	public void testSub() {
		System.out.println("sub");
		assertEquals(8,calc.sub(a, b));
	}

	@Test
	public void testMul() {
		System.out.println("mul");
		assertEquals(20,calc.mul(a, b));
	}

	@Test
	public void testDiv() {
		System.out.println("div");
		assertEquals(5,calc.div(a, b));
	}
	@Test(expected=ArithmeticException.class)
	public void testDivEx() {
		System.out.println("divEx");
		calc.div(10, 0);
	}

	@Test
	public void testShowObject() {
		assertNotNull(calc.showObject());
	}
	@Test(timeout=100)
	public void testDisplay() {
		calc.display();
	}

}
