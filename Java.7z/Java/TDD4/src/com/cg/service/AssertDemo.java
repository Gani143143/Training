package com.cg.service;

import java.util.Scanner;

public class AssertDemo {

	public static void main(String[] args) {
		System.out.println("Enter a value");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		assert(n>0):" n should be +ve value";
		System.out.println("Entered value is:"+n);
	}

}
