package com.capgemini.ShoppingKart2.utility;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.ShoppingKart2.bean.Item;

public class ItemRepositories {
public static Map<Integer, Item>itemlist=new HashMap<>();
static {
	itemlist.put(12, new Item(12,"pen",10000));
	itemlist.put(13, new Item(13,"Laptop",20000));
	itemlist.put(14, new Item(14,"Mobile",30000));
	itemlist.put(15, new Item(15,"Apple",100000));
}
public Map<Integer, Item> getitems() {
	
	return itemlist;
}
}
