package com.capgemini.ShoppingKart2.UI;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.ShoppingKart2.Exception.ShoppingExceptions;
import com.capgemini.ShoppingKart2.bean.Item;
import com.capgemini.ShoppingKart2.bean.Order;
import com.capgemini.ShoppingKart2.service.CustomerOrderService;
import com.capgemini.ShoppingKart2.service.CustomerOrderServiceImpl;
import com.capgemini.ShoppingKart2.utility.ItemRepositories;



public class MainUI {
	double price;
	Scanner scanner=new Scanner(System.in);
	CustomerOrderService service = new CustomerOrderServiceImpl();
	
private void Register() {
String name;
String phoneno;
boolean flag=true;
do {
	scanner=new Scanner(System.in);
	System.out.println("enter Name");
	name=scanner.nextLine();
	try {
		flag=service.isNameValid(name);
		
		if(flag)
			throw new ShoppingExceptions();
	}catch(ShoppingExceptions e) {
		System.err.println("first letter in the name should be capital throws");
	}
	
}while(flag);

do {
	scanner=new Scanner(System.in);
	System.out.println("enter phone number");
	phoneno=scanner.next();
	try {
		flag=service.isPhoneNoValid(phoneno);
		
		if(flag)
			throw new ShoppingExceptions();
	}catch(ShoppingExceptions e) {
		System.err.println("Invalid phone");
	}
	
}while(flag);
System.out.println(name +"rigistered successfully");
String choice;
do {
	System.out.println("1.placing order\n2.display the cart\n3.exit");
	int option=scanner.nextInt();
	switch(option) {
	case 1:
		placeOrder();
		break;
	case 2:
		displayCart();
		break;
	case 3:System.out.println("Thank you for Visiting..!!");
		System.exit(0);
		
	default:
		System.out.println("Enter Option 1 to 3  only");
	}
	System.out.println("Press Y to continue");
	scanner.nextLine();
	choice = scanner.nextLine();
	
	
}while(choice.equalsIgnoreCase("y"));

}
	
	
	private void displayCart() {
		 double amount=0;
		 Order num=new Order();
		HashMap<Integer, Order> itemList=(HashMap<Integer, Order>) service.getItems();
		Iterator<Order> it=itemList.values().iterator();
		while(it.hasNext())
		{
		num = it.next();
			System.out.println(num);
			amount=amount + num.getQuantity();
			System.out.println(amount);
		}
	
		System.out.println("Total Amount is: Rs." + amount);
}


	private void placeOrder() {
	ItemRepositories obj=new ItemRepositories();
	Map<Integer, Item> itemList=obj.getitems();
	
	Iterator<Item> it=itemList.values().iterator();
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
	int id;
	do {
		
		System.out.println("enetr itemId");
	id=scanner.nextInt();
	if(id>11&&id<16)
	{
		System.out.println("Enter Quantity");
		int quantity = scanner.nextInt();
		Iterator<Integer> itm=itemList.keySet().iterator();
		while(itm.hasNext())
		{
			if(id==itm.next()) {
				price=itemList.get(id).getPrice();
				double amount=quantity*price;
				
				Order item=new Order(id,id,quantity,amount);
				CustomerOrderService service=new CustomerOrderServiceImpl();
				boolean flag=service.addToCart(item);
				if(flag)
					System.out.println(id+"  order id item added successfully");
				else
					System.out.println("not added");
				
			}
		}

	}
	else
	{
		System.out.println("enter itemId's only");
	}
	}while(id<11||id>15);
}


	public static void main(String[] args) {
		
		MainUI clientUI = new MainUI();
		System.out.println("Welcome to the Product Management System");
		int choice = 2;
		boolean flag = true;
        do {
		System.out.println(" 1.Register \n 0.Exit");
		try {
			Scanner scanner1=new Scanner(System.in);
			choice = scanner1.nextInt();

			switch (choice) {
			case 1:
				clientUI.Register();
				flag=false;
				break;
			case 0:System.out.println("Come back Soon..!!");
				System.exit(0);
			default:
				System.out.println("Please enter the Choice 1 or 0");
				flag=true;

			}
		} catch (InputMismatchException e) {
			System.err.println("Please enter 1 or 0 only");
		}
        }while(flag);
	}

	

}
