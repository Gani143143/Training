package com.capgemini.ShoppingKart2.service;

import java.util.HashMap;
import java.util.List;

import com.capgemini.ShoppingKart2.Exception.ShoppingExceptions;
import com.capgemini.ShoppingKart2.bean.Item;
import com.capgemini.ShoppingKart2.bean.Order;

public interface CustomerOrderService {
boolean addToCart(Order item);
List<Order>printOrderedItems();
	public HashMap<Integer, Order>getItems();
	boolean isNameValid(String name) throws ShoppingExceptions;
	boolean isPhoneNoValid(String phone) throws ShoppingExceptions;
}
