package com.cg;

public interface Calculator {
	double operation(double a,double b);

}
