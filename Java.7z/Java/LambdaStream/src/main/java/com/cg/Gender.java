package com.cg;

public enum Gender {
	MALE,FEMALE

}
