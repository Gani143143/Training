package com.cg;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class ConsumerSupplierDemo {

	public static void main(String[] args) {
		Consumer<String> consumer=(name)->{
			System.out.println("Consumer printing:"+name);
		};
		consumer.accept("gani");
		//supplier
		Supplier<String> supplier=()->"Hello from supplier";
		System.out.println(supplier.get());
		consumer.accept(supplier.get());
		List<Integer> mylist=Arrays.asList(30,50,10,20,40);
		//write consumer definition to print list of values
		Consumer<List<Integer>> printlistconsumersort=(list)->{
			Collections.sort(list);
			for(Integer i : list) {
				System.out.print(i+" ");
			}
			System.out.println();
		};
		printlistconsumersort.accept(mylist);
		//BiConsumer
		//write consumer definition to print list of values in sorted order
		BiConsumer<String,Integer> biConsumer=(name,age)->{
			System.out.println("BiConsumer printing name is:"+ name);
			System.out.println("BiConsumer printing age is:"+ age);
		};
		biConsumer.accept("gani", 20);

	}

}
