package com.cg;

import java.util.Arrays;
import java.util.List;

public class PersonStreamDemo {

	public static void main(String[] args) {
		List<Person> people=Arrays.asList(
				new Person("priya",36,Gender.FEMALE),
				new Person("sriya",19,Gender.FEMALE),
				new Person("riya",25,Gender.FEMALE),
				new Person("anji",36,Gender.MALE),
				new Person("gani",21,Gender.MALE),
				new Person("fransis",21,Gender.MALE));
		//print all person details
		people.stream().forEach(System.out::println);
		//print all females
		people.stream().filter(p->p.getGender().equals(Gender.FEMALE))
		.map(p->p.getName()).forEach(System.out::println);
		//print all males names uppercase and age>18
		people.stream().filter(p->p.getAge()>18).filter(p->p.getGender().equals(Gender.MALE))
		.map(p->p.getName()).map(p->p.toUpperCase()).forEach(System.out::println);

	}

}
