package com.cg;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.omg.Messaging.SyncScopeHelper;

public class BasicStream {

	public static void main(String[] args) {
		List<Integer> list=Arrays.asList(3,5,6);
		System.out.println(list);
		System.out.println("collect");
		int sum=list.stream().collect(Collectors.summingInt(i->i));
		System.out.println("Sum="+sum);
		//concat
		List<Integer> list1=Arrays.asList(10,20,30);
		List<Integer> list2=Arrays.asList(11,22,33);
		Stream<Integer> concatvalue=Stream.concat(list1.stream(),list2.stream());
		System.out.println("Concat values");
		//concatvalue.forEach((i)->System.out.println(i));
		concatvalue.forEach(System.out::println);
		System.out.println("Count");
		System.out.println("list2 count:"+list.stream().count());
		List<Integer> list3=Arrays.asList(6,7,9,1,4,2,3,5);
		System.out.println("Sorted data");
	    list3.stream().sorted().forEach(System .out::println);
	    System.out.println("Count of even numbers");
	    System.out.println(list3.stream().filter(n->n%2==0).count());
	    Predicate<Integer> p=n->n%2==0;
	    System.out.println("allMatch:"+list3.stream().allMatch(p));
	    System.out.println("anyMatch:"+list3.stream().anyMatch(p));
	    System.out.println("noMatch:"+list3.stream().noneMatch(p));
	    List<String> cities=Arrays.asList("Pune","Bangalore","Mumbai","Chennai");
	    cities.stream().forEach(System.out::println);
	    System.out.println("print the cities,namelength>5");
	    List<String> resultlist=cities.stream().filter((name->name.length()>5)).collect(Collectors.toList());
	    resultlist.stream().forEach(System.out::println);
	    System.out.println("Each city name length");
	    cities.stream().map(s->s.length()).forEach(System.out::println);
	    Optional<Integer> sumvalue=list.stream().reduce((a,b)->a+b);
	    System.out.println(sumvalue);
	    System.out.println(sumvalue.isPresent()?sumvalue.get():"No value");
	    

	}

}
