package com.java.parallelBean;
 public class Bean {
private String name,dob,password;
private Long bal, phoneno;
private long bacc;
public Bean(String name, String dob, String password, Long bal, Long phoneno, long bacc) {
	super();
	this.name = name;
	this.dob = dob;
	this.password = password;
	this.bal = bal;
	this.phoneno = phoneno;
	this.bacc = bacc;
}
@Override
public String toString() {
	return "Bean [name=" + name + ", dob=" + dob + ", password=" + password + ", bal=" + bal + ", phoneno=" + phoneno
			+ ", bacc=" + bacc + "]";
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Long getBal() {
	return bal;
}
public void setBal(Long bal) {
	this.bal = bal;
}
public Long getPhoneno() {
	return phoneno;
}
public void setPhoneno(Long phoneno) {
	this.phoneno = phoneno;
}
public long getBacc() {
	return bacc;
}
public void setBacc(long bacc) {
	this.bacc = bacc;
}
public long fund(String string) {
	return 0;
}
 }

