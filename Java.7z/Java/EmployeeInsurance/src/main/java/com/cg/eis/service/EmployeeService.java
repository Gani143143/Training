package com.cg.eis.service;
import java.util.List;
import com.cg.eis.bean.Employee;
public interface EmployeeService {
     int add(Employee employee);
        Employee getEmployee(int employeeId);
        List<Employee> getemployees();
}