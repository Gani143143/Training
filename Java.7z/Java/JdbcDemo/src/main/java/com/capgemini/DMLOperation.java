package com.capgemini;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.utility.DBConnection;

public class DMLOperation {
	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet resultSet=null;
	boolean status=false;
	int row=-1;
	Scanner scanner=new Scanner(System.in);
	public void insert() {
		try {
			System.out.println("Enter tid,name,marks");
			int tid=scanner.nextInt();
			String name=scanner.next();
			double marks=scanner.nextDouble();
			connection=DBConnection.getConnection();
			statement=connection.prepareStatement("insert into trainee values(?,?,?)");
			statement.setInt(1, tid);
			statement.setString(2, name);
			statement.setDouble(3, marks);
			row=statement.executeUpdate();
			System.out.println(row+"inserted");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void update() {
		try {
			System.out.println("Enter tid to update");
			int tid=scanner.nextInt();
			System.out.println("Enter the new Marks");
			double marks=scanner.nextDouble();
			connection=DBConnection.getConnection();
			statement=connection.prepareStatement("update trainee set marks=? where tid=?");
			statement.setDouble(1, marks);
			statement.setInt(2, tid);
			row=statement.executeUpdate();
			System.out.println(row+"updated");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void delete() {
		try {
			System.out.println("Enter tid to delete");
			int tid=scanner.nextInt();
			connection=DBConnection.getConnection();
			statement=connection.prepareStatement("delete from trainee where tid=?");
			statement.setInt(1, tid);
			row=statement.executeUpdate();
			System.out.println(row+"deleted");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void create() {
		try {
			String query="create table trainee(tid number(5) primary key,"+"name varchar2(25),marks number(7,2))";
			statement=connection.prepareStatement(query);
			status=statement.execute();
			System.out.println("Table created:"+status);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		DMLOperation dml=new DMLOperation();
		//dml.create();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter 1.insert \n2.update \n3.delete\n4.viewAll\n5.viewbyId");
		int option=scanner.nextInt();
		switch (option) {
		case 1:
			dml.insert();
			break;
		case 2:
			dml.update();
			break;
		case 3:
			dml.delete();
			break;
		default:
			System.out.println("Enter 1 to 5 only");
			break;
		}
	}

}
